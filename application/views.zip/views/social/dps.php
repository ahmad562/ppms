<style type="text/css">
    table th {
        color: white;
        background-color: black;
    }
</style>
        <div class="pcoded-content" >
            <div class="pcoded-inner-content">

                <!-- Main-body start -->
                <div class="main-body">
                    <div class="page-wrapper">
                        <!-- Page-header start -->
                        <div class="page-header">
                            <div class="page-header-title">
                                <!-- <h4>DPS Detail</h4> -->


                            </div>
                            <div class="page-header-breadcrumb">

                            </div>
                        </div>
                        <!-- Page-header end -->
                        <!-- Page-body start -->
                        <div class="page-body">
                            <div class="row">
                                    <div class="col-sm-12">
                                    <!-- Zero config.table start -->
                                    <div class="card">
                                        <div class="card-header">
                                            <h4>DPS Detail</h4>
                                        </div>
                                        <div class="card-block">
                                            <div class="dt-responsive table-responsive">
                                                <form role="form" method="post" id="create_item"
                                                    enctype="multipart/form-data" action="" autocomplete="off"
                                                    onsubmit="return confirm('Are you sure you want to submit this form?');">

                                                    <table class="table gridexample">

                                                         <tr>
                                                            <td>DP Name</td>
                                                        </tr>
                                                        <tr>
                                                            <td><input type="text" autofocus
                                                                    placeholder="" required
                                                                     class="form-control"
                                                                    name="name" tabindex="1"></td>
                                                                </tr>
                                                                <tr>
                                                                    <td>Other Details</td>
                                                                </tr>
                                                            <tr>
                                                            <td>Total Land</td>
                                                            <td><input type="text" autofocus
                                                                    placeholder="" required
                                                                     class="form-control"
                                                                    name="total_land" tabindex="1"></td>
                                                             <td>DLA</td>
                                                            <td><input type="text" autofocus
                                                                    placeholder="" required
                                                                     class="form-control"
                                                                    name="dla" tabindex="1"></td>
                                                                </tr>
                                                                <tr>
                                                            <td>Nland</td>
                                                            <td><input type="text" autofocus
                                                                    placeholder="" required
                                                                     class="form-control"
                                                                    name="n_land" tabindex="1"></td>
                                                             <td>DNLA</td>
                                                            <td><input type="text" autofocus
                                                                    placeholder="" required
                                                                     class="form-control"
                                                                    name="dnla" tabindex="1"></td> 
                                                                </tr>
                                                                <tr>
                                                            <td>Allownces</td>
                                                            <td><input type="text" autofocus
                                                                    placeholder="" required
                                                                     class="form-control"
                                                                    name="allownces" tabindex="1"></td>
                                                             <td>DA</td>
                                                            <td><input type="text" autofocus
                                                                    placeholder="" required
                                                                     class="form-control"
                                                                    name="da" tabindex="1"></td>   
                                                                </tr>
                                                                <tr>
                                                                    <td>Training</td>
                                                            <td><input type="text" autofocus
                                                                    placeholder="" required
                                                                     class="form-control"
                                                                    name="training" tabindex="1"></td>
                                                             <td>DT</td>
                                                            <td><input type="text" autofocus
                                                                    placeholder="" required
                                                                     class="form-control"
                                                                    name="dt" tabindex="1"></td> 
                                                                </tr>
                                                            
                                                            <td><button type="submit"
                                                                    class="btn btn-block btn-outline btn-primary"
                                                                    id="add" name="add" tabindex="2">Save
                                                                    Record</button></td>
                                                        </tr>
                                                    </table>
                                                </form>
                                            </div>
                                        </div>


                                        <!--/span-->
                                    </div>
                                    <!--/row-->

                                </div>
                                <!-- Table -->
                                
                                 <!-- Table -->
                            </div>

                        </div>
                       