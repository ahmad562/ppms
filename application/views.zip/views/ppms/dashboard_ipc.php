<div class="pcoded-content">
    <div class="pcoded-inner-content">

        <!-- Main-body start -->
        <div class="main-body">
            <div class="page-wrapper">
                <!-- Page-header start -->
                <div class="page-header">
                    <div class="page-header-title">
                        <h4>IPC Detail</h4>

                    </div>
                    <div class="page-header-breadcrumb">

                    </div>
                </div>
                <!-- Page-header end -->
                <!-- Page-body start -->
                <div class="page-body">
                    <div class="row">
                        <div class="col-sm-12">
                            <!-- Zero config.table start -->
                            <div class="card">
                                
                                <div class="card-block">
                                    <div class="dt-responsive table-responsive">
                           

                                    <table  class="table  table-bordered nowrap">
                                            <thead>
                                                <?php /*?><tr>
<td align="center">
<img src="<?php echo base_url('img/ipc/detail.png')?>">
<br>
IPC Detail
</td>

<td align="center">
<img src="<?php echo base_url('img/ipc/timeline.png')?>">
<br>
TimeLine
</td>

<td align="center">
<img src="<?php echo base_url('img/ipc/remarks.png')?>">
<br>
Remarks
</td>

<td align="center">
<img src="<?php echo base_url('img/ipc/payment.png')?>">
<br>
Add Payments

</td>
                                                
<td align="center">
<img src="<?php echo base_url('img/ipc/checklist.png')?>">
<br>
Checklist
</td>
</tr>
<?php */?>
                                                <tr>
<td align="center">
<img src="<?php echo base_url('img/ipc/ipc_payment.png')?>"><br>
IPC'S Payment Detail
</td>

<td align="center">
<img src="<?php echo base_url('img/ipc/mobilization.png')?>"><br>
Mobilization Detail
</td>

<td align="center">
<img src="<?php echo base_url('img/ipc/bill.png')?>"><br>
Bill Summary Detail
</td>


<td align="center">
<img src="<?php echo base_url('img/ipc/progress.png')?>"><br>
Financial Progress
</td>


<td align="center">
<img src="<?php echo base_url('img/ipc/certificate.png')?>"><br>
Payment certificate
</td>


                                                </tr>
                                            </thead>
                                    </table>











                                </div>



                            </div>
                            <!--/span-->
                            
      </div>
    </div>
	
	
                            </div>
                            <!--/row-->

                        </div>
                    </div>

                </div>


               