        <div class="pcoded-content" >
            <div class="pcoded-inner-content">
                <!-- Main-body start -->
                <div class="main-body">
                    <div class="page-wrapper">
                        <!-- Page-header start -->
                        <div class="page-header">
                            <div class="page-header-title">
                                <!-- <h4>DPS Detail</h4> -->


                            </div>
                            <div class="page-header-breadcrumb">

                            </div>
                        </div>
                        <!-- Page-header end -->
                        <!-- Page-body start -->
                        <div class="page-body" style=" margin-top:-50px ;">
                          <!--   <div>
                                
                           
                            <table class="table nowrap" style="margin-bottom: -50px; margin-top:-50px ;">
                                            <tr>
                                                <td> -->
                            <div class="container">
                                <div class="row">
                                    
                                    <div class="col-sm-4">
                                        <a href="<?php echo base_url()?>Complaint/tier_one">
                                        <div class="card gradient-1" style="background-color:green; border-top: white;">
                                <center>
                            <div class="card-body" >
                                <h6 class="card-title text-white" style="font-weight:bold;">Tier 1</h6>
                                
                                
                            </div>
                            </center>
                           </div>
                           </a>
                       </div>
                       
                           <div class="col-sm-4">
                            <a href="<?php echo base_url()?>Complaint/tier_two">
                               <div class="card gradient-1" style="background-color:blue; border-top: white;">
                                <center>
                            <div class="card-body">
                                <h6 class="card-title text-white" style="font-weight:bold;">Tier 2</h6>
                                
                            </div>
                            </center>
                            
                           </div>
                       </a>
                           </div>
                           <div class="col-sm-4">
                            <a href="<?php echo base_url()?>Complaint/tier_three">
                               <div class="card gradient-1" style="background-color:orange; border-top: white;">
                            <center>
                            <div class="card-body">
                                <h6 class="card-title text-white" style="font-weight:bold;">Tier 3</h6>
                                
                            </div>
                            </center>
                     
                           </div>
                       </a>
                           </div>
                           
                                              
                                            </div>
                                        </div>


                                        <!--/span-->
                                    </div>
                                    <!--/row-->

                                </div>
                                <!-- Table -->
                                
                                 <!-- Table -->
                            </div>
                            </div>
                        </div>