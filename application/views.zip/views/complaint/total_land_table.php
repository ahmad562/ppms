<style> table tr td{
        text-align: center;
    }
table tr th{
        text-align: center;
    }</style>
<div class="card">
                                        
                                        <div class="card-block">
                                            <div class="card-header">
                                                 <h4 align="center" colspan="10" style="padding:2px;font-family: Jameel Noori Nastaleeq; font-size: 25px;font-weight: bold;">"عوضانہ تحت تحصیل خوازہ خیلہ  (GREATER GRAVITY WATER SUPPLY SCHEME MINGORA)گریٹر گریوٹی واٹر سپلائی سکیم مینگورہ"
            <br> Main Pipline</h4>
                                            </div>
                                            <div class="card-body">
                                            <div class="container">
                                                <div class="row">
                                                    <div class="col-12" style="padding:0px;">
                                       <table border="1px" width="100%">
                                                       <tr><td colspan="8" align="center"><b>Summary</b></td></tr>
                                                        <tr>
                                                            <th>Category</th>
                                                            <th>DPs</th>
                                                            <th>Budget</th>
                                                            <th>Paid DPs</th>
                                                            <th>Paid %</th>
                                                            <th>Paid Amount</th>
                                                            <th>Paid %age</th>
                                                            <td rowspan="4" align="center"><button class="btn btn-primary" onclick="load_land_detail()">Detail</button></td>
                                                        </tr>
                                                    
                                                   
                                                  
                                                      <tr>
                                                            <td>BOR</td>
                                                             <td>22</td>  
                                                             <td>38,431,403</td>  
                                                             <td>21</td>  
                                                             <td>95.45%</td>  
                                                             <td>28,992,101</td>  
                                                             <td>75.44%</td>
                                                             
                                                        </tr>
                                                            <td>IVS</td>
                                                            <td>22</td>  
                                                            <td>2,418,555</td>   
                                                            <td>21</td>  
                                                            <td>95.45%</td>  
                                                            <td>1,821,689</td>  
                                                            <td>75.32%</td>
                                                                     
                                                        <tr>
                                                            <td>Severity and Vulnerability Allowance</td>
                                                            <td>N/A</td> 
                                                            <td>N/A</td> 
                                                            <td>N/A</td> 
                                                            <td>N/A</td> 
                                                            <td>N/A</td> 
                                                            <td>N/A</td>
                                                                   
                                                        </tr>
                                                 
                                              
                                          </table>
                                                    </div>
                                                    <!-- <div class="col-1 align-self-center text-center" style="padding:0px;">
                                                        
                                                    </div> -->
                                                </div>
                                            </div>
                                        </div>
                                      </div>
                                  </div>