<div class="card">
    <div class="card-block">
       <div class="container" style="overflow:scroll;">
    <div class="row">
    <div class="col-12">
        
            
       
        <style>
    table tr td{
        text-align: center;
        padding: 2px;
    }
    table tr th{
        text-align: center;
        padding: 2px;
    }
</style>

<table border="1px" cellpadding="0" cellspacing="0" width="100%" id="simpletable">
    <tr>
        <td align="center" colspan="10" style="padding:10px;font-family: Jameel Noori Nastaleeq; font-size: 25px;font-weight: bold;">"عوضانہ تحت تحصیل خوازہ خیلہ  (GREATER GRAVITY WATER SUPPLY SCHEME MINGORA)گریٹر گریوٹی واٹر سپلائی سکیم مینگورہ"
            <br> Main Pipline
</td>
        
    </tr>
    <tr bgcolor="#89CFF0">
        <th>S#</th>
        <th>DP Name with Father/Husband Name</th>
        <th colspan="3" style="padding:0px;">
            <table align="center" ><tr><th>Payment details</th></tr></table>
            <table border="1px" cellpadding="0" cellspacing="0" width="100%"><tr><th style="width: 100%;"> &ensp; &ensp; BOR &ensp;&ensp;</th>
        <th width="20%"> &ensp;&ensp; IVS &ensp;&ensp;</th>
        <th width="40%">Severity<br> and <br>vulnerability<br> Allowance</th></tr></table>
        </th>
        <!-- 
        <td></td>
        <td></td> -->
         
        <th>Total payment received</th>
        <th>% age Total payment received</th>
        <th>Recipient Pictures</th>
        <th>Voucher /Cheque snip (As proof</th>
        <th>Remarks ( In case of <br>non-payment or any<br> impediments in payment</th>
        
    </tr>
    
    <tr>
        <td>1</td>
        <td> Bakht Rokhan S/O Sarzamin Khan </td>
        <td width="5%"> 9474851.2 </td>
        <td width="5%"> 10400040.56 </td>
        <td></td>
        <td> 9803174.72  </td>
        <td>0%</td>
        <td>Shared in Hard Drive USB</td>
        <td>Shared in Hard Drive USB</td>
        <td>Died</td>
        
    </tr>
    <tr>
        <td>2</td>
        <td> Shaad Khan S/O Jawara Khan </td>
        <td> 2515664.09 </td>
        <td> 2761665.979 </td>
        <td></td>
        <td> 2603355.863 </td>
        <td>100%</td>
        <td>Shared in Hard Drive USB</td>
        <td>Shared in Hard Drive USB</td>
        <td></td>
        
    </tr>
    <tr>
        <td>3</td>
        <td> Niaz Khan S/O Shanoraq </td>
        <td> 3118527.12 </td>
        <td> 3421500.2666 </td>
        <td></td>
        <td> 3225365.7202 </td>
        <td>100%</td>
        <td>Shared in Hard Drive USB</td>
        <td>Shared in Hard Drive USB</td>
        <td></td>
        
    </tr>
    <tr>
        <td>4</td>
        <td> Ayaz S/O Sha Room Khan </td>
        <td> 1041993.56 </td>
        <td> 1145442.6678 </td>
        <td></td>
        <td> 1079781.1566 </td>
        <td>100%</td>
        <td>Shared in Hard Drive USB</td>
        <td>Shared in Hard Drive USB</td>
        <td></td>
        
    </tr>
    <tr>
        <td>5</td>
        <td> Sajjad Khan S/O Sha Room Khan </td>
        <td> 1041993.56 </td>
        <td> 1145442.6678 </td>
        <td></td>
        <td> 1079781.1566 </td>
        <td>100%</td>
        <td>Shared in Hard Drive USB</td>
        <td>Shared in Hard Drive USB</td>
        <td></td>
        
    </tr>
    <tr>
        <td>6</td>
        <td> Imtiaz Khan S/O Sha Room Khan </td>
        <td> 1041993.56 </td>
        <td> 1145442.6678 </td>
        <td></td>
        <td> 1079781.1566 </td>
        <td>100%</td>
        <td>Shared in Hard Drive USB</td>
        <td>Shared in Hard Drive USB</td>
        <td></td>
        
    </tr>
    <tr>
        <td>7</td>
        <td> Sarhad Bacha S/O Makhor </td>
        <td> 746759.35 </td>
        <td> 819232.4582 </td>
        <td></td>
        <td> 772270.6654 </td>
        <td>100%</td>
        <td>Shared in Hard Drive USB</td>
        <td>Shared in Hard Drive USB</td>
        <td></td>
        
    </tr>
    <tr>
        <td>8</td>
        <td> Jani Room Bacha S/O Makhor </td>
        <td> 746759.35 </td>
        <td> 819232.4582 </td>
        <td></td>
        <td> 772270.6654 </td>
        <td>100%</td>
        <td>Shared in Hard Drive USB</td>
        <td>Shared in Hard Drive USB</td>
        <td></td>
        
    </tr>
    <tr>
        <td>9</td>
        <td> Jahani Mulk S/O Makhor </td>
       <td> 746759.35 </td>
        <td> 819232.4582 </td>
        <td></td>
        <td> 772270.6654 </td>
        <td>100%</td>
        <td>Shared in Hard Drive USB</td>
        <td>Shared in Hard Drive USB</td>
        <td></td>
        
    </tr>
    <tr>
        <td>10</td>
        <td> Abdullah Shah S/O Makhor </td>
       <td> 746759.35 </td>
        <td> 819232.4582 </td>
        <td></td>
        <td> 772270.6654 </td>
        <td>100%</td>
        <td>Shared in Hard Drive USB</td>
        <td>Shared in Hard Drive USB</td>
        <td></td>
        
    </tr>
    <tr>
        <td>11</td>
        <td> Yousaf Shah S/O Makhor </td>
        <td> 746759.35 </td>
        <td> 819232.4582 </td>
        <td></td>
        <td> 772270.6654 </td>
        <td>100%</td>
        <td>Shared in Hard Drive USB</td>
        <td>Shared in Hard Drive USB</td>
        <td></td>
        
    </tr>
    <tr>
        <td>12</td>
        <td> Pura Khan S/O Sharif Khan </td>
        <td> 12833280.2 </td>
        <td> 14086349.96 </td>
        <td></td>
        <td> 13278862.12 </td>
        <td>100%</td>
        <td>Shared in Hard Drive USB</td>
        <td>Shared in Hard Drive USB</td>
        <td></td>
        
    </tr>
    <tr>
        <td>13</td>
        <td> Siyaho Bibi W/O Kara Khan </td>
        <td> 465176.02 </td>
        <td> 511556.9196 </td>
        <td></td>
        <td> 482232.3612 </td>
        <td>100%</td>
        <td>Shared in Hard Drive USB</td>
        <td>Shared in Hard Drive USB</td>
        <td></td>
        
    </tr>
    <tr>
        <td>14</td>
        <td> Muhammad Nisar Khan S/O Kara Khan </td>
        <td> 525958.83 </td>
        <td> 578281.7352  </td>
        <td></td>
        <td> 545132.2344 </td>
        <td>100%</td>
        <td>Shared in Hard Drive USB</td>
        <td>Shared in Hard Drive USB</td>
        <td></td>
        
    </tr>
    <tr>
        <td>15</td>
        <td> Raham Nisar Khan S/O Kara Khan </td>
        <td> 542086.22 </td>
        <td> 596816.4062 </td>
        <td></td>
        <td> 562604.4214 </td>
        <td>100%</td>
        <td>Shared in Hard Drive USB</td>
        <td>Shared in Hard Drive USB</td>
        <td></td>
        
    </tr>
    <tr>
        <td>16</td>
        <td> Jan Nisar Khan S/O Kara Khan </td>
        <td> 542086.22 </td>
        <td> 596816.4062 </td>
        <td></td>
        <td> 562604.4214 </td>
        <td>100%</td>
        <td>Shared in Hard Drive USB</td>
        <td>Shared in Hard Drive USB</td>
        <td></td>
        
    </tr>
    <tr>
        <td>17</td>
        <td> Jahangir Khan S/O Kara Khan </td>
        <td> 542086.22 </td>
        <td> 596816.4062 </td>
        <td></td>
        <td> 562604.4214 </td>
        <td>100%</td>
        <td>Shared in Hard Drive USB</td>
        <td>Shared in Hard Drive USB</td>
        <td></td>
        
    </tr>
    <tr>
        <td>18</td>
        <td> Bakht Rehbar Bibi D/O Kara Khan </td>
        <td> 270420.98 </td>
        <td> 296554.736 </td>
        <td></td>
        <td> 279554.992 </td>
        <td>100%</td>
        <td>Shared in Hard Drive USB</td>
        <td>Shared in Hard Drive USB</td>
        <td></td>
        
    </tr>
    <tr>
        <td>19</td>
        <td> Ziyati Bakht Bibi D/O Kara Khan </td>
        <td> 270420.98 </td>
        <td> 296554.736 </td>
        <td></td>
        <td> 279554.992 </td>
        <td>100%</td>
        <td>Shared in Hard Drive USB</td>
        <td>Shared in Hard Drive USB</td>
        <td></td>
        
    </tr>
    <tr>
        <td>20</td>
        <td> Mubarak Bibi D/O Kara Khan W/O Hazrat Sher </td>
        <td> 270420.98 </td>
        <td> 296554.736 </td>
        <td></td>
        <td> 279554.992 </td>
        <td>100%</td>
        <td>Shared in Hard Drive USB</td>
        <td>Shared in Hard Drive USB</td>
        <td></td>
        
    </tr>
    <tr>
        <td>21</td>
        <td> Sadaqat Bibi D/O Kara Khan </td>
        <td> 270420.98 </td>
        <td> 296554.736 </td>
        <td></td>
        <td> 279554.992 </td>
        <td>100%</td>
        <td>Shared in Hard Drive USB</td>
        <td>Shared in Hard Drive USB</td>
        <td></td>
        
    </tr>
    <tr>
        <td>22</td>
        <td> Saranzeb Khan S/O Alamzeb Khan </td>
        <td> 270420.98 </td>
        <td> 296554.736 </td>
        <td></td>
        <td> 279554.992 </td>
        <td>100%</td>
        <td>Shared in Hard Drive USB</td>
        <td>Shared in Hard Drive USB</td>
        <td></td>
        
    </tr>
    <tr>
        <td></td>
        <td>Total</td>
        <td> 38465692.87 </td>
        <td> 42093408.497 </td>
        <td> -   </td>
        <td> 39810713.2348 </td>
        <td>100%</td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
</table>
 </div>
    </div>
</div> 
    </div>
</div>
