<style >
    table tr td{
        align-items:center;
    }
</style>

<div class="pcoded-content" >
            <div class="pcoded-inner-content">
                <!-- Main-body start -->
                <div class="main-body">
                    <div class="page-wrapper">
                        <!-- Page-header start -->
                        <div class="page-header">
                           <!--  <div class="page-header-title">
                                <h4>Safegaurd Report</h4>
                            </div> -->
                            <div class="page-header-breadcrumb">

                            </div>
                        </div>
                        <!-- Page-header end -->
                        <!-- Page-body start -->
                        <div class="page-body" >
<div class="card"style="margin-right:20px;" >
    <div class="card-block">
       <div class="container" style="overflow:scroll;margin-right:20px">
    <div class="row" >
    <div class="col-12">
<table border="1px" cellpadding="3px" cellspacing="0px" width="100%">
    <tr >
        <th colspan="33" style="font-size: 18px;">KHYBER PAKHTUNKHWA CITIES IMPROVEMENT PROJECT (KPCIP)</th>
    </tr>
    <tr>
        <th colspan="33" style="font-size: 18px;">Financing : ADB Loan 4160-PAK and AIIB Loan (L0214A)</th>
        
    </tr>
    <tr style="border-bottom: 4px solid black;">
        <th colspan="33" style="font-size: 18px;">Disbursement Targets for 2024</th>
        
       
    </tr>
    
    <tr>
        <td><b>Sr.</b></td>
        <td><b>Description</b></td>
     
        <td>Contract Amount</td>
        <td>Previous Disbursements</td>
        <td><b>Jan</b> 2024<br><br> PKR Millions</td>
        <td><b>Feb</b> 2024<br><br> PKR Millions</td>
        <td><b>Mar</b> 2024<br><br> PKR Millions</td>
        <td><b>Apr</b> 2024<br><br> PKR Millions</td>
        <td><b>May</b> 2024<br><br> PKR Millions</td>
        <td><b>Jun</b> 2024<br><br> PKR Millions</td>
        <td><b>Jul</b> 2024<br><br> PKR Millions</td>
        <td><b>Aug</b> 2024<br><br> PKR Millions</td>
        <td><b>Sep</b> 2024<br><br> PKR Millions</td>
        <td><b>Oct</b> 2024<br><br> PKR Millions</td>
        <td><b>Nov</b> 2024<br><br> PKR Millions</td>
        <td><b>Dec</b> 2024<br><br> PKR Millions</td>
        <td><b>Total</b><br><br> PKR Millions</td>
       
    </tr>
    <tr style="border-bottom: 4px solid black;">
        <th>1</th>
        <td><b>Civil Works</b> </td>
    
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        
        
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        
        
    </tr>
    <tr>
        <td></td>
        <td><b>OCB/KPCIP/CW-01</b></td>
        
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        
        
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td></td>
        <td align="right"><b>Lot-1</b>: Green Urban Spaces / Parks<b>Abbottabad</b></td>
     
        
        <td> 1,174,979,732 </td>
        <td> 435.00 </td>
        <td> 189.52 </td>
        <td> 191.11 </td>
        <td> 138.10 </td>
        <td> 156.14 </td>
        <td> 68.12 </td>
        <td> 80.57 </td>
        <td>  </td>
        <td>  </td>
        <td>  </td>
        <td>  </td>
        <td>  </td>
        <td></td>
        <td> 823.56 </td>
    </tr>
    <tr>
        <td></td>
        <td align="right"><b>Lot-2</b>: Green Urban Spaces / Parks <b>Kohat</b></td>
    
        
        <td> 389,954,626 </td>
        <td> 278.00 </td>
        <td> 68.70 </td>
        <td> 78.23 </td>
        <td> 59.44 </td>
        <td> 87.49 </td>
        <td> 64.95 </td>
        <td> 81.98 </td>
        <td> 67.03 </td>
        <td> 79.91 </td>
        <td> 68.92 </td>
        <td> 78.02 </td>
        <td>  </td>
        <td>  </td>
        <td> 734.66 </td>
    </tr>
    <tr>
        <td></td>
        <td align="right"><b>Lot-3</b>: Green Urban Spaces / Parks <b>Mardan</b></td>
        
        <td> 582,639,408 </td>
        <td> 87.00 </td>
        <td>  </td>
        <td>  </td>
        <td>  </td>
        <td>  </td>
        <td>  </td>
        <td>  </td>
        <td>  </td>
        <td>  </td>
        <td>  </td>
        <td>  </td>
        <td>  </td>
        <td> </td>
        <td>  </td>
       
    </tr>
    <tr>
        <td></td>
        <td align="right"><b>Lot-4</b>: Green Urban Spaces / Parks <b>Mingora</b></td>
  
        
        <td> 287,980,154 </td>
        <td> 75.00 </td>
        <td> 32.51 </td>
        <td> 60.00 </td>
        <td> 81.00 </td>
        <td> 81.00 </td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td> 254.51 </td>
        
    </tr>
    <tr style="border-bottom: 4px solid black;">
        <td></td>
        <td align="right"><b>Lot-5</b>: Green Urban Spaces / Parks <b>Peshawar</b></td>
     
        
        <td> 1,056,665,600 </td>
        <td> 769.00 </td>
        <td> 94.11 </td>
        <td> 184.48 </td>
        <td> 209.63 </td>
        <td> 52.41 </td>
        <td>  </td>
        <td>  </td>
        <td>  </td>
        <td>  </td>
        <td>  </td>
        <td>  </td>
        <td>  </td>
        <td>  </td>
        <td> 540.62 </td>
      
    </tr>
    <tr>
        <td></td>
        <td><b>OCB/KPCIP/CW-02</b></td>
      
        
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td>  </td>
        
    </tr>
    <tr>
        <td></td>
        <td align="right"><b>Lot-1</b>: Water Supply Schemes <b>(Abbottabad)</b></td>

        
        <td> 8,503,650,701 </td>
        <td> 1,245.00 </td>
        <td></td>
        <td> 30.00 </td>
        <td> 130.00 </td>
        <td> 230.00 </td>
        <td> 265.00 </td>
        <td> 280.00 </td>
        <td> 285.00 </td>
        <td> 280.00 </td>
        <td> 280.00 </td>
        <td> 290.00 </td>
        <td> 300.00 </td>
        <td> 350.00 </td>
        <td> 2,720.00 </td>

    </tr>
    <tr>
        <td></td>
        <td align="right"><b>Lot-2</b>: Water Supply Schemes <b>(WTP Abbottabad)</b></td>
            
        <td> 2,596,193,225 </td>
        <td> 422.00 </td>
        <td></td>
        <td> 30.00 </td>
        <td> 50.00 </td>
        <td> 50.00 </td>
        <td> 60.00 </td>
        <td> 55.00 </td>
        <td> 60.00 </td>
        <td> 65.00 </td>
        <td> 45.00 </td>
        <td> 45.00 </td>
        <td> 55.00 </td>
        <td> 60.00 </td>
        <td> 575.00 </td>
        
    </tr>
    <tr>
        <td></td>
        <td align="right"><b>Lot-3</b>: Water Supply Schemes <b>(Kohat)</b></td>
        
        
        <td> 4,646,925,103 </td>
        <td> 799.00 </td>
        <td>  </td>
        <td> 132.44 </td>
        <td> 256.51 </td>
        <td> 297.87 </td>
        <td> 298.33 </td>
        <td> 253.26 </td>
        <td> 308.56 </td>
        <td> 373.61 </td>
        <td> 369.89 </td>
        <td> 287.18 </td>
        <td> 310.41 </td>
        <td> 300.19 </td>
        <td> 3,188.25 </td>
       
    </tr>
    <tr style="border-bottom: 4px solid black;">
        <td></td>
        <td align="right"><b>Lot-4</b>: Water Supply Schemes <b>(Peshawar)</b></td>
      
        
        <td> 2,595,271,296 </td>
        <td> 462.00 </td>
        <td> 34.57 </td>
        <td> 34.57 </td>
        <td> 119.69 </td>
        <td> 151.52 </td>
        <td> 272.51 </td>
        <td> 215.70 </td>
        <td> 301.72 </td>
        <td> 260.75 </td>
        <td> 217.91 </td>
        <td> 162.49 </td>
        <td> 121.74 </td>
        <td> 105.53 </td>
        <td> 1,998.70 </td>
       
    </tr>
    <tr>
        <td></td>
        <td><b>OCB/KPCIP/CW-03</b></td>
       
        
        
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td>  </td>
        <td></td>
        <td></td>
        <td></td>
        <td>    </td>
        <td></td>
        <td></td>
        <td></td>
        <td>    </td>
        <td></td>
        
    </tr>
    <tr>
        <td></td>
        <td align="right"><b>Lot-1</b>: Sewerage Treatment Plants (STP) - <b>Kohat</b></td>
       
        <td> 6,731,940,946 </td>
        <td> 1,644.00 </td>
        <td> 238.95 </td>
        <td> 172.82 </td>
        <td> 104.73 </td>
        <td> 214.68 </td>
        <td> 334.61 </td>
        <td> 198.50 </td>
        <td> 290.44 </td>
        <td> 297.07 </td>
        <td> 253.67 </td>
        <td> 276.78 </td>
        <td> 222.18 </td>
        <td> 328.55 </td>
        <td> 2,932.98 </td>
       
    </tr>
    <tr style="border-bottom: 4px solid black;">
        <td></td>
        <td align="right"><b>Lot-2</b>: Sewerage Treatment Plants (STP) - <b>Mardan</b></td>
      
        
        <td> 8,313,864,123 </td>
        <td> 1,620.00 </td>
        <td> 203.00 </td>
        <td> 200.00 </td>
        <td> 250.00 </td>
        <td> 250.00 </td>
        <td> 250.00 </td>
        <td> 250.00 </td>
        <td> 250.00 </td>
        <td> 300.00 </td>
        <td> 300.00 </td>
        <td> 200.00 </td>
        <td> 300.00 </td>
        <td> 300.00 </td>
        <td> 3,053.00 </td>
      
    </tr>
    <tr>
        <td></td>
        <td><b>OCB/KPCIP/CW-04</b></td>
        
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td>  </td>
        
    </tr>
    <tr>
        <td></td>
        <td align="right"><b>Lot-1</b>: Water Supply Scheme WTP - <b>Mingora</b></td>
       
        
        <td> 7,506,000,000 </td>
        <td>  </td>
        <td></td>
        <td></td>
        <td> 1,125.90 </td>
        <td> 75.06 </td>
        <td> 150.12 </td>
        <td> 150.12 </td>
        <td> 300.24 </td>
        <td> 300.24 </td>
        <td> 300.24 </td>
        <td> 300.24 </td>
        <td> 300.24 </td>
        <td> 300.24 </td>
        <td> 3,302.64 </td>
       
    </tr>
    <tr style="border-bottom: 4px solid black;">
        <td></td>
        <td align="right"><b>Lot-2: Water Supply Scheme Pipeline - Mingora</b></td>
    
        
        <td> 20,328,313,394 </td>
        <td> 3,487.00 </td>
        <td> 938.44 </td>
        <td> 989.64 </td>
        <td> 1,030.03 </td>
        <td> 1,080.53 </td>
        <td> 298.93 </td>
        <td> 210.43 </td>
        <td> 547.47 </td>
        <td> 825.72 </td>
        <td> 647.14 </td>
        <td> 804.69 </td>
        <td> 1,095.44 </td>
        <td> 986.62 </td>
        <td> 9,455.08 </td>
        
    </tr>
    <tr style="border-bottom: 4px solid black;">
        <td></td>
        <td><b>Sub-Total for Civil Works</b> </td>
               
        <th> 64,714,378,308.03 </th>
        <th> 11,323.00 </th>
        <th> 1,799.80 </th>
        <th> 2,103.29 </th>
        <th> 3,555.02 </th>
        <th> 2,726.70 </th>
        <th> 2,062.57 </th>
        <th> 1,775.56 </th>
        <th> 2,410.45 </th>
        <th> 2,782.30 </th>
        <th> 2,482.77 </th>
        <th> 2,444.39 </th>
        <th> 2,705.01 </th>
        <th> 2,731.13 </th>
        <th> 29,579.00 </th>
        
    </tr>
   
    <tr>
        <th>3</th>
        <td><b>Project Management Cost</b> </td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
       
    </tr>
    <tr>
        <td></td>
        <td>Project Management &amp; Construction Supervision Consultants (PMCSC)</td>
    
        <td>2,695,712,080</td>
        <td>1,272</td>
        <td>235</td>
        <td>50</td>
        <td>50</td>
        <td>60</td>
        <td>60</td>
        <td>60</td>
        <td>80</td>
        <td>80</td>
        <td>80</td>
        <td>80</td>
        <td>80</td>
        <td>80</td>
        <td> 995 </td>
       
    </tr>
    <tr style="border-bottom: 4px solid black;">
        <td></td>
        <td>PMU/CIUs Operational and Incremental Cost</td>
                
        <td></td>
        <td></td>
        <td> 20 </td>
        <td> 20 </td>
        <td> 20 </td>
        <td> 20 </td>
        <td> 20 </td>
        <td> 20 </td>
        <td> 40 </td>
        <td> 40 </td>
        <td> 40 </td>
        <td> 40 </td>
        <td> 40 </td>
        <td> 40 </td>
        <td> 360 </td>
    </tr>
    <tr style="border-bottom: 4px solid black;">
        <td></td>
        <td><b>Sub-Total for Project Management Cost</b> </td>
                
        <td></td>
        <td></td>
        <td> 255 </td>
        <td> 70 </td>
        <td> 70 </td>
        <td> 80 </td>
        <td> 80 </td>
        <td> 80 </td>
        <td> 120 </td>
        <td> 120 </td>
        <td> 120 </td>
        <td> 120 </td>
        <td> 120 </td>
        <td> 120 </td>
        <td> 1,355 </td>
       
    </tr>
    <tr style="border-bottom: 4px solid black;">
        
        <th></th>
        <td><b>Total for Civil Works + Supervision/Project Management (PKR)</b></td>
        <th></th>
        <th></th>
        <th> 2,055 </th>
        <th> 2,173 </th>
        <th> 3,625 </th>
        <th> 2,807 </th>
        <th> 2,143 </th>
        <th> 1,856 </th>
        <th> 2,530 </th>
        <th> 2,902 </th>
        <th> 2,603 </th>
        <th> 2,564 </th>
        <th> 2,825 </th>
        <th> 2,851 </th>
        <th> 30,934 </th>
      
    </tr>
    <tr style="border-bottom: 4px solid black;">
        <td></td>
        <td><b>Total Amounts in US$</b></td>
    
        
        <th></th>
        <th></th>
        <th> $7.34 </th>
        <th> $7.76 </th>
        <th> $12.95 </th>
        <th> $10.02 </th>
        <th> $7.65 </th>
        <th> $6.63 </th>
        <th> $9.04 </th>
        <th> $10.37 </th>
        <th> $9.30 </th>
        <th> $9.16 </th>
        <th> $10.09 </th>
        <th> $10.18 </th>
        <th> $110.48 </th>
        
    </tr>
    <tr>
        <td></td>
        <td>ADB Share (US$)</td>
      
        <td></td>
        <td></td>
        <td> $5.32 </td>
        <td> $5.64 </td>
        <td> $9.42 </td>
        <td> $7.29 </td>
        <td> $5.56 </td>
        <td> $4.82 </td>
        <td> $6.57 </td>
        <td> $7.53 </td>
        <td> $6.76 </td>
        <td> $6.66 </td>
        <td> $7.33 </td>
        <td> $7.40 </td>
        <td> $71.69 </td>
        
    </tr>
    <tr>
        <td></td>
        <td>AIIB Share  (US$)</td>
        
        <td></td>
        <td></td>
        <td> $2.02 </td>
        <td> $2.12 </td>
        <td> $3.53 </td>
        <td> $2.73 </td>
        <td> $2.09 </td>
        <td> $1.81 </td>
        <td> $2.47 </td>
        <td> $2.83 </td>
        <td> $2.54 </td>
        <td> $2.50 </td>
        <td> $2.76 </td>
        <td> $2.78 </td>
        <td> $38.79 </td>
  
    </tr>
    
</table>
 </div>
    </div>
</div> 
    </div>
</div>
</div>
</div>
</div>
</div>
</div>