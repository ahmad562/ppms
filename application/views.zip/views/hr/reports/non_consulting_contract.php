<div class="pcoded-content">
    <div class="pcoded-inner-content">
        <div class="main-body">
            <div class="page-wrapper">
                <div class="page-header">
                    <div class="page-header-title"></div>
                    <div class="page-header-breadcrumb">
                    
                    </div>
                </div>
                <div class="page-body">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="card">
                                
                                <div class="card-block">
                                    <div class="dt-responsive table-responsive">
                                    <table cellspacing="0" cellpadding="0" style="width:954pt; margin-right:9pt; margin-left:9pt; border-collapse:collapse; float:left;">
        <thead>
            <tr>
                <td colspan="12" style="width:712.15pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.4pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:11pt;"><strong>Table A5.2: Works, Goods, and Non-Consulting Services Contracts Awarded Under the Project</strong></p>
                </td>
            </tr>
            <tr>
                <td rowspan="3" style="width:65.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; font-size:9pt;"><strong>Package No.</strong></p>
                </td>
                <td rowspan="3" style="width:63.35pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; font-size:9pt;"><strong>Name of Contract</strong></p>
                </td>
                <td rowspan="3" style="width:55.4pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Contractor/</strong></p>
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Supplier</strong></p>
                </td>
                <td rowspan="3" style="width:40.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Contract Type</strong></p>
                </td>
                <td rowspan="3" style="width:37.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; font-size:9pt;"><strong>Contract Award Date</strong></p>
                </td>
                <td colspan="2" style="width:80.55pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; font-size:9pt;"><strong>Completion date</strong></p>
                </td>
                <td rowspan="3" style="width:39.5pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; font-size:9pt;"><strong>Currency&nbsp;</strong></p>
                </td>
                <td colspan="2" rowspan="2" style="width:83.25pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Contract Amount (million) PKR</strong></p>
                </td>
                <td rowspan="3" style="width:48.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Expenditure (MA+IPC&apos;s) in million.</strong></p>
                </td>
                <td rowspan="3" style="width:99.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; font-size:9pt;"><strong>Contract Status&nbsp;</strong><strong><span style="font-size:6pt;"><sup>d</sup></span></strong></p>
                </td>
            </tr>
            <tr style="height:22pt;">
                <td rowspan="2" style="width:34.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Original</strong></p>
                </td>
                <td rowspan="2" style="width:34.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Revised&nbsp;</strong><strong><span style="font-size:6pt;"><sup>b</sup></span></strong></p>
                </td>
            </tr>
            <tr style="height:2.3pt;">
                <td style="width:37.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:bottom; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Original</strong></p>
                </td>
                <td style="width:34.5pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Revised</strong></p>
                </td>
            </tr>
            <tr>
                <td style="width:65.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:63.35pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:55.4pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:40.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:37.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:34.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:34.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:39.5pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:37.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:34.5pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:48.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:99.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
        </thead>
        <tbody>
            <?php 
            
$this->db->select('*');
$this->db->from('hr_non_consulting_services');
$this->db->join('emp', 'hr_non_consulting_services.contractor_id = emp.emp_id', 'left');
$this->db->join('ppms_subproject', 'hr_non_consulting_services.subproject_id = ppms_subproject.subproject_id', 'left');
$this->db->join('city', 'ppms_subproject.city_id = city.city_id', 'left');
$results = $this->db->get()->result();
            
         foreach($results as $results){   
            ?>
            <tr>
                <td style="width:65.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
<p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><?php 
$pname=$this->db->query("select project_name from ppms_project where project_id=$results->project_id")->row();

echo $pname->project_name;?>, <?php echo $results->subproject_name;?>: <?php echo $results->city_name;?>.</p>
                </td>
                <td rowspan="5" style="width:63.35pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">
                    <?php echo $results->contract_name;?></p>
                </td>
                <td style="width:55.4pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">

                    <?php 
                                        $cidnew = $this->db->query("SELECT emp_id,emp_name FROM ppms_subproject_assign AS psa,emp AS e
                                        WHERE psa.`contractor_id`=e.`emp_id` and subproject_id=$results->subproject_id")->result();
                                        $z1=1;
                                        foreach($cidnew as $cidnew){
                                            echo $cidnew->emp_name." - ";
                                        //echo "(".$z1.") "."<br>";
                                        $z1++;
                                        }?>
                
                
                </p>
                </td>
                <td rowspan="13" style="width:40.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><?php echo $results->contract_type;?></p>
                </td>
                <td style="width:37.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><?php echo $results->award_date;?></p>
                </td>
                <td style="width:34.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><?php echo $results->completion_date_org;?></p>
                </td>
                <td style="width:34.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><?php echo $results->completion_date_rev;?></p>
                </td>
                <td style="width:39.5pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><?php echo $results->currency;?></p>
                </td>
                <td style="width:37.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><?php echo $results->contract_amount_org;?></p>
                </td>
                <td style="width:34.5pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><?php echo $results->contract_amount_rev;?></p>
                </td>
                <td style="width:48.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><?php echo $results->expenditure;?></p>
                </td>
                <td style="width:99.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-indent:0.5pt; font-size:9pt;"><?php echo $results->contract_status;?></p>
                </td>
            </tr>
          <?php }?>
        </tbody>
    </table>