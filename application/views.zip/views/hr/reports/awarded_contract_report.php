<div class="pcoded-content">
    <div class="pcoded-inner-content">
        <div class="main-body">
            <div class="page-wrapper">
                <div class="page-header">
                    <div class="page-header-title"></div>
                    <div class="page-header-breadcrumb">
                    
                    </div>
                </div>
                <div class="page-body">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="card">
                                
                                <div class="card-block">
                                    <div class="dt-responsive table-responsive">
     <table cellspacing="0" cellpadding="0" border="1" style="width:954pt; margin-right:9pt; margin-left:9pt; border-collapse:collapse; float:left;">
        <thead>
            <tr style="height:24.6pt;">
                <td colspan="12" style="width:705.05pt; border-bottom-style:solid; border-bottom-width:1pt; padding-right:5.4pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:11pt;"><strong>Table A5.1: Consultancy Contracts Awarded Under the Project</strong></p>
                </td>
            </tr>
            <tr style="height:16.85pt;">
                <td rowspan="2" style="width:12pt; border-style:solid; border-width:1pt; padding-right:4.9pt; padding-left:4.9pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>No</strong></p>
                </td>
                <td rowspan="2" style="width:108.9pt; border-style:solid; border-width:1pt; padding-right:4.9pt; padding-left:4.9pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Name of Consultancy Package</strong></p>
                </td>
                <td rowspan="2" style="width:42.05pt; border-style:solid; border-width:1pt; padding-right:4.9pt; padding-left:4.9pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Firm/ Individual</strong></p>
                </td>
                <td rowspan="2" style="width:69.15pt; border-style:solid; border-width:1pt; padding-right:4.9pt; padding-left:4.9pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Name of Firm or Individual</strong></p>
                </td>
                <td rowspan="2" style="width:44.95pt; border-style:solid; border-width:1pt; padding-right:4.9pt; padding-left:4.9pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Contract Award Date</strong></p>
                </td>
                <td colspan="2" style="width:90pt; border-top-style:solid; border-top-width:1pt; border-right-style:solid; border-right-width:1pt; border-bottom-style:solid; border-bottom-width:1pt; padding-right:4.9pt; padding-left:5.4pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Completion&nbsp;</strong></p>
                </td>
                <td rowspan="2" style="width:39.55pt; border-style:solid; border-width:1pt 0.75pt 1pt 1pt; padding-right:5.03pt; padding-left:4.9pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Currency&nbsp;</strong><strong><span style="font-size:6pt;"><sup>b</sup></span></strong></p>
                </td>
                <td colspan="2" style="width:80.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Contract Amount (million)</strong></p>
                </td>
                <td rowspan="2" style="width:61.05pt; border-style:solid; border-width:1pt 1pt 1pt 0.75pt; padding-right:4.9pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Disbursement (million)</strong></p>
                </td>
                <td rowspan="2" style="width:60.05pt; border-style:solid; border-width:1pt; padding-right:4.9pt; padding-left:4.9pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Contract Status&nbsp;</strong><strong><span style="font-size:6pt;"><sup>c</sup></span></strong></p>
                </td>
            </tr>
            <tr style="height:16.45pt;">
                <td style="width:44.65pt; border-right-style:solid; border-right-width:1pt; padding-right:4.9pt; padding-left:5.4pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;"><strong>Original</strong></p>
                </td>
                <td style="width:34.55pt; border-right-style:solid; border-right-width:1pt; padding-right:4.9pt; padding-left:5.4pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Revised&nbsp;</strong><strong><span style="font-size:6pt;"><sup>a</sup></span></strong></p>
                </td>
                <td style="width:34.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Original</strong></p>
                </td>
                <td style="width:34.55pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Revised</strong></p>
                </td>
            </tr>
            <tr style="height:13.8pt;">
                <td colspan="12" style="width:705.05pt; border-top-style:solid; border-top-width:1pt; border-right-style:solid; border-right-width:1pt; border-left-style:solid; border-left-width:1pt; padding-right:4.9pt; padding-left:4.9pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;"><strong>&nbsp;</strong></p>
                </td>
            </tr>
        </thead>
        <tbody>
            <tr style="height:13.8pt;">
                <td colspan="12" style="width:705.05pt; border-top-style:solid; border-top-width:1pt; border-right-style:solid; border-right-width:1pt; border-left-style:solid; border-left-width:1pt; padding-right:4.9pt; padding-left:4.9pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;"><strong>A.</strong><strong>&nbsp;&nbsp;</strong><strong>Loan financed Consultants&nbsp;</strong></p>
                </td>
            </tr>

            <?php
           $contracts=$this->db->query("select * from hr_consultancy_contracts as cc,ppms_service_tbl as pst
           where cc.emp_id=pst.service_id and status_id=1
           ")->result();
            foreach ($contracts as $contract) { ?>
                                            <tr>
                                                <td><?php echo $contract->hr_cid; ?></td>
                                                <td><?php echo $contract->package; ?></td>
                                                <td><?php echo $contract->firm_indi_id; ?></td>
                                                <td><?php echo $contract->s_fullname; ?></td>
                                                <td><?php echo $contract->contract_award; ?></td>
                                                <td><?php echo $contract->completion_date; ?></td>
                                                <td><?php echo $contract->revised_date; ?></td>
                                                <td><?php echo $contract->currency; ?></td>
                                                <td><?php echo $contract->cont_amt_orig; ?></td>
                                                <td><?php echo $contract->cont_amt_revised; ?></td>
                                                <td><?php echo $contract->disbursement; ?></td>
                                                <td><?php 
                                                if($contract->status_id==0){
                                                echo "Non Active";
                                                }else{
                                                    echo "Active";

                                                } ?></td>
                                               
                                            </tr>
                                            <?php } ?>


                                            <tr style="height:13.8pt;">
                <td colspan="12" style="width:705.05pt; border-top-style:solid; border-top-width:1pt; border-right-style:solid; border-right-width:1pt; border-left-style:solid; border-left-width:1pt; padding-right:4.9pt; padding-left:4.9pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;"><strong>A.</strong><strong>&nbsp;&nbsp;</strong><strong>Grant financed Consultants&nbsp;</strong></p>
                </td>
            </tr>

            <?php
           $contracts=$this->db->query("select * from hr_consultancy_contracts as cc,ppms_service_tbl as pst
           where cc.emp_id=pst.service_id and loan_grant='Grant'
           ")->result();
            foreach ($contracts as $contract) { ?>
                                            <tr>
                                                <td><?php echo $contract->hr_cid; ?></td>
                                                <td><?php echo $contract->package; ?></td>
                                                <td><?php echo $contract->firm_indi_id; ?></td>
                                                <td><?php echo $contract->s_fullname; ?></td>
                                                <td><?php echo $contract->contract_award; ?></td>
                                                <td><?php echo $contract->completion_date; ?></td>
                                                <td><?php echo $contract->revised_date; ?></td>
                                                <td><?php echo $contract->currency; ?></td>
                                                <td><?php echo $contract->cont_amt_orig; ?></td>
                                                <td><?php echo $contract->cont_amt_revised; ?></td>
                                                <td><?php echo $contract->disbursement; ?></td>
                                                <td><?php 
                                                if($contract->status_id==0){
                                                echo "Non Active";
                                                }else{
                                                    echo "Active";

                                                } ?></td>
                                               
                                            </tr>
                                            <?php } ?>
           
           
        </tbody>
    </table>
   