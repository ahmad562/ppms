 <p style="margin-top:0pt; margin-bottom:0pt;"><strong>&nbsp;</strong></p>
    <p style="margin-top:0pt; margin-bottom:0pt;"><strong>&nbsp;</strong></p>
    <p style="margin-top:0pt; margin-bottom:0pt;"><strong>&nbsp;</strong></p>
    <p style="margin-top:0pt; margin-bottom:0pt;"><strong>&nbsp;</strong></p>
    <p style="margin-top:0pt; margin-bottom:0pt;"><strong>&nbsp;</strong></p>
    <p style="margin-top:0pt; margin-bottom:0pt;"><strong>&nbsp;</strong></p>
    <p style="margin-top:0pt; margin-bottom:0pt;"><strong>&nbsp;</strong></p>
    <p style="margin-top:0pt; margin-bottom:0pt;"><strong>&nbsp;</strong></p>
    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;"><strong>&nbsp;</strong></p>
    <table cellspacing="0" cellpadding="0" style="width:954pt; margin-right:9pt; margin-left:9pt; border-collapse:collapse; float:left;">
        <thead>
            <tr>
                <td colspan="14" style="width:852.85pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.4pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:11pt;"><strong>Appendix-3-Table A3.2: Individual Consultants Recruitment Monitoring</strong></p>
                </td>
            </tr>
            <tr>
                <td rowspan="2" style="width:46.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;"><strong>Package #</strong></p>
                </td>
                <td rowspan="2" style="width:87.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;"><strong>Name of Contract Package</strong></p>
                </td>
                <td rowspan="2" style="width:36.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;"><strong>Est. Amt.&nbsp;</strong></p>
                </td>
                <td style="width:46.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;"><strong>&nbsp;</strong></p>
                </td>
                <td colspan="9" style="width:532.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;"><strong>Milestone Dates</strong></p>
                </td>
                <td style="width:50.05pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;"><strong>&nbsp;</strong></p>
                </td>
            </tr>
            <tr>
                <td style="width:46.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;"><strong>Planned/ Approved</strong></p>
                </td>
                <td style="width:44.25pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;"><strong>ToRs / Budget shared with ADB</strong></p>
                </td>
                <td style="width:49.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;"><strong>ADB Clearance</strong></p>
                </td>
                <td style="width:43.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;"><strong>EOI Advert</strong></p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;"><strong>Submission 1 to ADB</strong></p>
                </td>
                <td style="width:47.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;"><strong>ADB approval&nbsp;</strong></p>
                </td>
                <td style="width:46.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;"><strong>Contract Signing</strong></p>
                </td>
                <td style="width:53.35pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;"><strong>Intended completion&nbsp;</strong></p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;"><strong>Submission 2 to ADB2</strong></p>
                </td>
                <td style="width:47.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;"><strong>ADB Approval&nbsp;</strong></p>
                </td>
                <td style="width:50.05pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;"><strong>Awarded Amount</strong></p>
                </td>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td rowspan="2" style="width:46.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">KPCIP-IC-PMU-01</p>
                </td>
                <td rowspan="2" style="width:87.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">Monitoring &amp; Evaluation Specialist</p>
                </td>
                <td rowspan="2" style="width:36.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">61,508</p>
                </td>
                <td style="width:46.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">Planned</p>
                </td>
                <td style="width:44.25pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:49.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:43.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:47.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:46.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:53.35pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:47.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td rowspan="2" style="width:50.05pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">53,910.15</p>
                </td>
            </tr>
            <tr>
                <td style="width:46.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">Actual</p>
                </td>
                <td style="width:44.25pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:49.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:43.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">17 Sep 2021</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">16 May 2022</p>
                </td>
                <td style="width:47.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">27 Jul 2022</p>
                </td>
                <td style="width:46.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">11 Aug 2022</p>
                </td>
                <td style="width:53.35pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">31 Dec 2026</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">12 Aug 2022</p>
                </td>
                <td style="width:47.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">N/A</p>
                </td>
            </tr>
            <tr>
                <td rowspan="2" style="width:46.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">KPCIP-IC-PMU-02</p>
                </td>
                <td rowspan="2" style="width:87.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">Social Safeguard Specialist</p>
                </td>
                <td rowspan="2" style="width:36.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">94,196</p>
                </td>
                <td style="width:46.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">Planned</p>
                </td>
                <td style="width:44.25pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:49.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:43.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:47.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:46.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:53.35pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:47.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td rowspan="2" style="width:50.05pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">48,269.55</p>
                </td>
            </tr>
            <tr>
                <td style="width:46.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">Actual</p>
                </td>
                <td style="width:44.25pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:49.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:43.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">17 Sep 2021</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">19 May 2022</p>
                </td>
                <td style="width:47.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">27 Jul 2022</p>
                </td>
                <td style="width:46.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">01 Aug 2022</p>
                </td>
                <td style="width:53.35pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">31 Dec 2026</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">12 Aug 2022</p>
                </td>
                <td style="width:47.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">N/A</p>
                </td>
            </tr>
            <tr>
                <td rowspan="2" style="width:46.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">KPCIP-IC-PMU-03</p>
                </td>
                <td rowspan="2" style="width:87.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">Environmental Safeguard Specialist</p>
                </td>
                <td rowspan="2" style="width:36.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">80,729</p>
                </td>
                <td style="width:46.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">Planned</p>
                </td>
                <td style="width:44.25pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:49.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:43.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:47.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:46.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:53.35pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:47.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td rowspan="2" style="width:50.05pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">100,000.00</p>
                </td>
            </tr>
            <tr>
                <td style="width:46.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">Actual</p>
                </td>
                <td style="width:44.25pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:49.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:43.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">17 Sep 2021</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">16 May 2022</p>
                </td>
                <td style="width:47.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">27 Jul 2022</p>
                </td>
                <td style="width:46.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">25 Aug 2022</p>
                </td>
                <td style="width:53.35pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">31 Dec 2026</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">31 Aug 2022</p>
                </td>
                <td style="width:47.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">N/A</p>
                </td>
            </tr>
            <tr>
                <td rowspan="2" style="width:46.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">KPCIP-IC-PMU-05</p>
                </td>
                <td rowspan="2" style="width:87.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">Procurement &amp; Contract Management Specialist</p>
                </td>
                <td rowspan="2" style="width:36.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">178,000</p>
                </td>
                <td style="width:46.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">Planned</p>
                </td>
                <td style="width:44.25pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:49.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:43.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:47.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:46.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:53.35pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:47.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td rowspan="2" style="width:50.05pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">246,896</p>
                </td>
            </tr>
            <tr>
                <td style="width:46.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">Actual</p>
                </td>
                <td style="width:44.25pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:49.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:43.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">17 Sep 2021</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">16 May 2022</p>
                </td>
                <td style="width:47.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">27 Jul 2022</p>
                </td>
                <td style="width:46.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">11 Aug 2022</p>
                </td>
                <td style="width:53.35pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">31 Dec 2026</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">12 Aug 2022</p>
                </td>
                <td style="width:47.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">N/A</p>
                </td>
            </tr>
            <tr>
                <td rowspan="2" style="width:46.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">KPCIP-IC-PMU-16</p>
                </td>
                <td rowspan="2" style="width:87.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">Skills &amp; Enterprise Development Specialist</p>
                </td>
                <td rowspan="2" style="width:36.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">142,525</p>
                </td>
                <td style="width:46.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">Planned</p>
                </td>
                <td style="width:44.25pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:49.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:43.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:47.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:46.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:53.35pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:47.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td rowspan="2" style="width:50.05pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">114,392.68</p>
                </td>
            </tr>
            <tr>
                <td style="width:46.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">Actual</p>
                </td>
                <td style="width:44.25pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:49.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:43.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">17 Sep 2021</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">20 May 2022</p>
                </td>
                <td style="width:47.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">27 Jul 2022</p>
                </td>
                <td style="width:46.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">11 Aug 2022</p>
                </td>
                <td style="width:53.35pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">31 Dec 2026</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">12 Aug 2022</p>
                </td>
                <td style="width:47.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">N/A</p>
                </td>
            </tr>
            <tr>
                <td rowspan="2" style="width:46.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">???</p>
                </td>
                <td rowspan="2" style="width:87.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">Scholarship Program Specialist</p>
                </td>
                <td rowspan="2" style="width:36.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">????</p>
                </td>
                <td style="width:46.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">Planned</p>
                </td>
                <td style="width:44.25pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:49.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:43.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:47.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:46.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:53.35pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:47.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td rowspan="2" style="width:50.05pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
            </tr>
            <tr>
                <td style="width:46.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">Actual</p>
                </td>
                <td style="width:44.25pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:49.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:43.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:47.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:46.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:53.35pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:47.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
            </tr>
            <tr>
                <td rowspan="2" style="width:46.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">KPCIP-IC-PMU-18</p>
                </td>
                <td rowspan="2" style="width:87.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">Research Specialist</p>
                </td>
                <td rowspan="2" style="width:36.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">147,276</p>
                </td>
                <td style="width:46.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">Planned</p>
                </td>
                <td style="width:44.25pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:49.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:43.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:47.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:46.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:53.35pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:47.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td rowspan="2" style="width:50.05pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">114,392.68</p>
                </td>
            </tr>
            <tr>
                <td style="width:46.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">Actual</p>
                </td>
                <td style="width:44.25pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:49.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:43.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">17 Sep 2021</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">20 May 2022</p>
                </td>
                <td style="width:47.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">27 Jul 2022</p>
                </td>
                <td style="width:46.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">11 Aug 2022</p>
                </td>
                <td style="width:53.35pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">31 Dec 2026</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">12 Aug 2022</p>
                </td>
                <td style="width:47.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">N/A</p>
                </td>
            </tr>
            <tr>
                <td rowspan="2" style="width:46.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">KPCIP-IC-PMU-15</p>
                </td>
                <td rowspan="2" style="width:87.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">Community Engagement and Behavioral Change Expert</p>
                </td>
                <td rowspan="2" style="width:36.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">152,027</p>
                </td>
                <td style="width:46.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">Planned</p>
                </td>
                <td style="width:44.25pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:49.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:43.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:47.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:46.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:53.35pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:47.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td rowspan="2" style="width:50.05pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">40,016.64</p>
                </td>
            </tr>
            <tr>
                <td style="width:46.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">Actual</p>
                </td>
                <td style="width:44.25pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:49.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:43.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">17 Sep 2021</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">20 May 2022</p>
                </td>
                <td style="width:47.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">27 Jul 2022</p>
                </td>
                <td style="width:46.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">11 Aug 2022</p>
                </td>
                <td style="width:53.35pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">31 Dec 2026</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">12 Aug 2022</p>
                </td>
                <td style="width:47.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">N/A</p>
                </td>
            </tr>
            <tr>
                <td rowspan="2" style="width:46.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">KPCIP-IC-PMU-04</p>
                </td>
                <td rowspan="2" style="width:87.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">Communication Specialist</p>
                </td>
                <td rowspan="2" style="width:36.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">54,948</p>
                </td>
                <td style="width:46.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">Planned</p>
                </td>
                <td style="width:44.25pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:49.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:43.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:47.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:46.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:53.35pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:47.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td rowspan="2" style="width:50.05pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">57,653.91</p>
                </td>
            </tr>
            <tr>
                <td style="width:46.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">Actual</p>
                </td>
                <td style="width:44.25pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:49.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:43.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">17 Sep 2021</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">16 May 2022</p>
                </td>
                <td style="width:47.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">27 Jul 2022</p>
                </td>
                <td style="width:46.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">11 Aug 2022</p>
                </td>
                <td style="width:53.35pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">31 Dec 2026</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">12 Aug 2022</p>
                </td>
                <td style="width:47.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">N/A</p>
                </td>
            </tr>
            <tr>
                <td rowspan="2" style="width:46.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">KPCIP-IC-PMU-17</p>
                </td>
                <td rowspan="2" style="width:87.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">Capacity Development Specialist - Gender &amp; Social Inclusion (WASH &amp; SWM)</p>
                </td>
                <td rowspan="2" style="width:36.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">147,276</p>
                </td>
                <td style="width:46.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">Planned</p>
                </td>
                <td style="width:44.25pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:49.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:43.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:47.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:46.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:53.35pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:47.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td rowspan="2" style="width:50.05pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">48,502.50</p>
                </td>
            </tr>
            <tr>
                <td style="width:46.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">Actual</p>
                </td>
                <td style="width:44.25pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:49.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:43.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">17 Sep 2021</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">20 May 2022</p>
                </td>
                <td style="width:47.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">27 Jul 2022</p>
                </td>
                <td style="width:46.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">11 Aug 2022</p>
                </td>
                <td style="width:53.35pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">31 Dec 2026</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">12 Aug 2022</p>
                </td>
                <td style="width:47.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">N/A</p>
                </td>
            </tr>
            <tr>
                <td rowspan="2" style="width:46.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">KPCIP-IC-CIUs-03-01A</p>
                </td>
                <td rowspan="2" style="width:87.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">Environment Specialist CIU Abbottabad</p>
                </td>
                <td rowspan="2" style="width:36.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">37,721</p>
                </td>
                <td style="width:46.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">Planned</p>
                </td>
                <td style="width:44.25pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:49.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:43.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:47.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:46.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:53.35pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:47.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td rowspan="2" style="width:50.05pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
            </tr>
            <tr>
                <td style="width:46.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">Actual</p>
                </td>
                <td style="width:44.25pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:49.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:43.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">28 Mar 2023</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">21 May 2023</p>
                </td>
                <td style="width:47.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">23 May 2023</p>
                </td>
                <td style="width:46.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">19 June 2023</p>
                </td>
                <td style="width:53.35pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">31 Dec 2026</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">21 Sep 2023</p>
                </td>
                <td style="width:47.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
            </tr>
            <tr>
                <td rowspan="2" style="width:46.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">KPCIP-IC-CIUs-03-02K</p>
                </td>
                <td rowspan="2" style="width:87.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">Environment Specialist CIU Kohat</p>
                </td>
                <td rowspan="2" style="width:36.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">37,721</p>
                </td>
                <td style="width:46.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">Planned</p>
                </td>
                <td style="width:44.25pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:49.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:43.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:47.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:46.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:53.35pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:47.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td rowspan="2" style="width:50.05pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
            </tr>
            <tr>
                <td style="width:46.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">Actual</p>
                </td>
                <td style="width:44.25pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:49.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:43.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">28 Mar 2023</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">21 May 2023</p>
                </td>
                <td style="width:47.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">23 May 2023</p>
                </td>
                <td style="width:46.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">19 June 2023</p>
                </td>
                <td style="width:53.35pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">31 Dec 2026</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">21 Sep 2023</p>
                </td>
                <td style="width:47.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
            </tr>
            <tr>
                <td rowspan="2" style="width:46.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">KPCIP-IC-CIUs-03-03M</p>
                </td>
                <td rowspan="2" style="width:87.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">Environment Specialist CIU Mardan</p>
                </td>
                <td rowspan="2" style="width:36.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">37,721</p>
                </td>
                <td style="width:46.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">Planned</p>
                </td>
                <td style="width:44.25pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:49.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:43.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:47.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:46.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:53.35pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:47.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:10pt;">&nbsp;</p>
                </td>
                <td rowspan="2" style="width:50.05pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
            </tr>
            <tr>
                <td style="width:46.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">Actual</p>
                </td>
                <td style="width:44.25pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:49.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:43.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">28 Mar 2023</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">21 May 2023</p>
                </td>
                <td style="width:47.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">23 May 2023</p>
                </td>
                <td style="width:46.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">19 June 2023</p>
                </td>
                <td style="width:53.35pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">31 Dec 2026</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">21 Sep 2023</p>
                </td>
                <td style="width:47.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
            </tr>
            <tr>
                <td rowspan="2" style="width:46.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">KPCIP-IC-CIUs-03-04P</p>
                </td>
                <td rowspan="2" style="width:87.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">Environment Specialist CIU Peshawar</p>
                </td>
                <td rowspan="2" style="width:36.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">37,721</p>
                </td>
                <td style="width:46.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">Planned</p>
                </td>
                <td style="width:44.25pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:49.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:43.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:47.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:46.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:53.35pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:47.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td rowspan="2" style="width:50.05pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
            </tr>
            <tr>
                <td style="width:46.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">Actual</p>
                </td>
                <td style="width:44.25pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:49.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:43.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">28 Mar 2023</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">21 May 2023</p>
                </td>
                <td style="width:47.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">23 May 2023</p>
                </td>
                <td style="width:46.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">19 June 2023</p>
                </td>
                <td style="width:53.35pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">31 Dec 2026</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">21 Sep 2023</p>
                </td>
                <td style="width:47.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
            </tr>
            <tr>
                <td rowspan="2" style="width:46.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">KPCIP-IC-CIUs-03-05S</p>
                </td>
                <td rowspan="2" style="width:87.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">Environment Specialist CIU Swat</p>
                </td>
                <td rowspan="2" style="width:36.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">37,721</p>
                </td>
                <td style="width:46.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">Planned</p>
                </td>
                <td style="width:44.25pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:49.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:43.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:47.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:46.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:53.35pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:47.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td rowspan="2" style="width:50.05pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
            </tr>
            <tr>
                <td style="width:46.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">Actual</p>
                </td>
                <td style="width:44.25pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:49.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:43.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">28 Mar 2023</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">21 May 2023</p>
                </td>
                <td style="width:47.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">23 May 2023</p>
                </td>
                <td style="width:46.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">19 June 2023</p>
                </td>
                <td style="width:53.35pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">31 Dec 2026</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">21 Sep 2023</p>
                </td>
                <td style="width:47.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
            </tr>
            <tr>
                <td rowspan="2" style="width:46.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">KPCIP-IC-CIUs- 02-1A</p>
                </td>
                <td rowspan="2" style="width:87.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">Social Safeguard Specialist CIU Abbottabad</p>
                </td>
                <td rowspan="2" style="width:36.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">37,150</p>
                </td>
                <td style="width:46.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">Planned</p>
                </td>
                <td style="width:44.25pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:49.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:43.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:47.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:46.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:53.35pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:47.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td rowspan="2" style="width:50.05pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
            </tr>
            <tr>
                <td style="width:46.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">Actual</p>
                </td>
                <td style="width:44.25pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:49.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:43.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">28 Mar 2023</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">27 May 2023</p>
                </td>
                <td style="width:47.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">1 June 2023</p>
                </td>
                <td style="width:46.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">19 June 2023</p>
                </td>
                <td style="width:53.35pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">31 Dec 2026</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">21 Sep 2023</p>
                </td>
                <td style="width:47.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
            </tr>
            <tr>
                <td rowspan="2" style="width:46.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">KPCIP-IC-CIUs- 02-2K</p>
                </td>
                <td rowspan="2" style="width:87.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">Social Safeguard Specialist CIU Kohat</p>
                </td>
                <td rowspan="2" style="width:36.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">37,150</p>
                </td>
                <td style="width:46.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">Planned</p>
                </td>
                <td style="width:44.25pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:49.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:43.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:47.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:46.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:53.35pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:47.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td rowspan="2" style="width:50.05pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
            </tr>
            <tr>
                <td style="width:46.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">Actual</p>
                </td>
                <td style="width:44.25pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:49.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:43.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">28 Mar 2023</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">27 May 2023</p>
                </td>
                <td style="width:47.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">1 June 2023</p>
                </td>
                <td style="width:46.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">19 June 2023</p>
                </td>
                <td style="width:53.35pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">31 Dec 2026</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">21 Sep 2023</p>
                </td>
                <td style="width:47.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
            </tr>
            <tr>
                <td rowspan="2" style="width:46.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">KPCIP-IC-CIUs- 02-3M</p>
                </td>
                <td rowspan="2" style="width:87.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">Social Safeguard Specialist CIU Mardan</p>
                </td>
                <td rowspan="2" style="width:36.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">37,150</p>
                </td>
                <td style="width:46.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">Planned</p>
                </td>
                <td style="width:44.25pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:49.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:43.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:47.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:46.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:53.35pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:47.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td rowspan="2" style="width:50.05pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
            </tr>
            <tr>
                <td style="width:46.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">Actual</p>
                </td>
                <td style="width:44.25pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:49.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:43.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">28 Mar 2023</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">27 May 2023</p>
                </td>
                <td style="width:47.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">1 June 2023</p>
                </td>
                <td style="width:46.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">19 June 2023</p>
                </td>
                <td style="width:53.35pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">31 Dec 2026</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">21 Sep 2023</p>
                </td>
                <td style="width:47.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
            </tr>
            <tr>
                <td rowspan="2" style="width:46.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">KPCIP-IC-CIUs- 02-4P</p>
                </td>
                <td rowspan="2" style="width:87.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">Social Safeguard Specialist CIU Peshawar</p>
                </td>
                <td rowspan="2" style="width:36.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">37,150</p>
                </td>
                <td style="width:46.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">Planned</p>
                </td>
                <td style="width:44.25pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:49.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:43.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:47.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:46.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:53.35pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:47.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td rowspan="2" style="width:50.05pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
            </tr>
            <tr>
                <td style="width:46.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">Actual</p>
                </td>
                <td style="width:44.25pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:49.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:43.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">28 Mar 2023</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">27 May 2023</p>
                </td>
                <td style="width:47.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">1 June 2023</p>
                </td>
                <td style="width:46.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">19 June 2023</p>
                </td>
                <td style="width:53.35pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">31 Dec 2026</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">21 Sep 2023</p>
                </td>
                <td style="width:47.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
            </tr>
            <tr>
                <td rowspan="2" style="width:46.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">KPCIP-IC-CIUs- 02-5S</p>
                </td>
                <td rowspan="2" style="width:87.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">Social Safeguard Specialist CIU Swat</p>
                </td>
                <td rowspan="2" style="width:36.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">37,150</p>
                </td>
                <td style="width:46.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">Planned</p>
                </td>
                <td style="width:44.25pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:49.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:43.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:47.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:46.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:53.35pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:47.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td rowspan="2" style="width:50.05pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
            </tr>
            <tr>
                <td style="width:46.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">Actual</p>
                </td>
                <td style="width:44.25pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:49.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
                <td style="width:43.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">28 Mar 2023</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">27 May 2023</p>
                </td>
                <td style="width:47.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">1 June 2023</p>
                </td>
                <td style="width:46.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">19 June 2023</p>
                </td>
                <td style="width:53.35pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">31 Dec 2026</p>
                </td>
                <td style="width:56.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">21 Sep 2023</p>
                </td>
                <td style="width:47.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:10pt;">&nbsp;</p>
                </td>
            </tr>
        </tbody>
    </table>
</div>
<p><br style="page-break-before:always; clear:both; mso-break-type:section-break;"></p>
<div>
    <h2 style="margin-top:0pt; margin-left:53.5pt; margin-bottom:12pt; text-indent:-18pt; text-align:left; font-size:11pt;">i)<span style="width:11.28pt; font:7pt 'Times New Roman'; display:inline-block;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><a name="_Toc148522787"></a><a name="_Hlk134781303"></a><a name="_Hlk147079676">Appendix-5: Contracts Already Awarded</a></h2>
    <table cellspacing="0" cellpadding="0" style="width:954pt; margin-right:9pt; margin-left:9pt; border-collapse:collapse; float:left;">
        <thead>
            <tr style="height:24.6pt;">
                <td colspan="12" style="width:705.05pt; border-bottom-style:solid; border-bottom-width:1pt; padding-right:5.4pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:11pt;"><strong>Table A5.1: Consultancy Contracts Awarded Under the Project</strong></p>
                </td>
            </tr>
            <tr style="height:16.85pt;">
                <td rowspan="2" style="width:12pt; border-style:solid; border-width:1pt; padding-right:4.9pt; padding-left:4.9pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>No</strong></p>
                </td>
                <td rowspan="2" style="width:108.9pt; border-style:solid; border-width:1pt; padding-right:4.9pt; padding-left:4.9pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Name of Consultancy Package</strong></p>
                </td>
                <td rowspan="2" style="width:42.05pt; border-style:solid; border-width:1pt; padding-right:4.9pt; padding-left:4.9pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Firm/ Individual</strong></p>
                </td>
                <td rowspan="2" style="width:69.15pt; border-style:solid; border-width:1pt; padding-right:4.9pt; padding-left:4.9pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Name of Firm or Individual</strong></p>
                </td>
                <td rowspan="2" style="width:44.95pt; border-style:solid; border-width:1pt; padding-right:4.9pt; padding-left:4.9pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Contract Award Date</strong></p>
                </td>
                <td colspan="2" style="width:90pt; border-top-style:solid; border-top-width:1pt; border-right-style:solid; border-right-width:1pt; border-bottom-style:solid; border-bottom-width:1pt; padding-right:4.9pt; padding-left:5.4pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Completion&nbsp;</strong></p>
                </td>
                <td rowspan="2" style="width:39.55pt; border-style:solid; border-width:1pt 0.75pt 1pt 1pt; padding-right:5.03pt; padding-left:4.9pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Currency&nbsp;</strong><strong><span style="font-size:6pt;"><sup>b</sup></span></strong></p>
                </td>
                <td colspan="2" style="width:80.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Contract Amount (million)</strong></p>
                </td>
                <td rowspan="2" style="width:61.05pt; border-style:solid; border-width:1pt 1pt 1pt 0.75pt; padding-right:4.9pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Disbursement (million)</strong></p>
                </td>
                <td rowspan="2" style="width:60.05pt; border-style:solid; border-width:1pt; padding-right:4.9pt; padding-left:4.9pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Contract Status&nbsp;</strong><strong><span style="font-size:6pt;"><sup>c</sup></span></strong></p>
                </td>
            </tr>
            <tr style="height:16.45pt;">
                <td style="width:44.65pt; border-right-style:solid; border-right-width:1pt; padding-right:4.9pt; padding-left:5.4pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;"><strong>Original</strong></p>
                </td>
                <td style="width:34.55pt; border-right-style:solid; border-right-width:1pt; padding-right:4.9pt; padding-left:5.4pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Revised&nbsp;</strong><strong><span style="font-size:6pt;"><sup>a</sup></span></strong></p>
                </td>
                <td style="width:34.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Original</strong></p>
                </td>
                <td style="width:34.55pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Revised</strong></p>
                </td>
            </tr>
            <tr style="height:13.8pt;">
                <td colspan="12" style="width:705.05pt; border-top-style:solid; border-top-width:1pt; border-right-style:solid; border-right-width:1pt; border-left-style:solid; border-left-width:1pt; padding-right:4.9pt; padding-left:4.9pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;"><strong>&nbsp;</strong></p>
                </td>
            </tr>
        </thead>
        <tbody>
            <tr style="height:13.8pt;">
                <td colspan="12" style="width:705.05pt; border-top-style:solid; border-top-width:1pt; border-right-style:solid; border-right-width:1pt; border-left-style:solid; border-left-width:1pt; padding-right:4.9pt; padding-left:4.9pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;"><strong>A.</strong><strong>&nbsp;&nbsp;</strong><strong>Loan financed Consultants&nbsp;</strong></p>
                </td>
            </tr>
            <tr style="height:55.2pt;">
                <td style="width:12pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">1</p>
                </td>
                <td style="width:108.9pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">KPCIP-Cons-05 / Monitoring &amp; Evaluation Specialist (Intermittent Basis)</p>
                </td>
                <td style="width:42.05pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Individual</p>
                </td>
                <td style="width:69.15pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Mr. Shafique Muhammad Khan</p>
                </td>
                <td style="width:44.95pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">15-Aug-22</p>
                </td>
                <td style="width:44.65pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">31-Dec-26</p>
                </td>
                <td style="width:34.55pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">N/a</p>
                </td>
                <td style="width:39.55pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">PKR</p>
                </td>
                <td style="width:34.8pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">12.96</p>
                </td>
                <td style="width:34.55pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">N/a</p>
                </td>
                <td style="width:61.05pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:60.05pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Active</p>
                </td>
            </tr>
            <tr style="height:41.4pt;">
                <td style="width:12pt; border-right-style:solid; border-right-width:0.75pt; border-left-style:solid; border-left-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">2</p>
                </td>
                <td style="width:108.9pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">KPCIP-Cons-05 / Environmental Specialist<br>(Intermittent Basis)</p>
                </td>
                <td style="width:42.05pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Individual</p>
                </td>
                <td style="width:69.15pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Dr. Abdul Qayyum Aslam</p>
                </td>
                <td style="width:44.95pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">29-Aug-22</p>
                </td>
                <td style="width:44.65pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">31-Dec-26</p>
                </td>
                <td style="width:34.55pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">N/a</p>
                </td>
                <td style="width:39.55pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">PKR</p>
                </td>
                <td style="width:34.8pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">21.81</p>
                </td>
                <td style="width:34.55pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">N/a</p>
                </td>
                <td style="width:61.05pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:60.05pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Active</p>
                </td>
            </tr>
            <tr style="height:41.4pt;">
                <td style="width:12pt; border-right-style:solid; border-right-width:0.75pt; border-left-style:solid; border-left-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">3</p>
                </td>
                <td style="width:108.9pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">KPCIP-Cons-05 / Social Safeguard Specialist<br>(Intermittent Basis)</p>
                </td>
                <td style="width:42.05pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Individual</p>
                </td>
                <td style="width:69.15pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Mr. Ali Akbar</p>
                </td>
                <td style="width:44.95pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">15-Aug-22</p>
                </td>
                <td style="width:44.65pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">31-Dec-26</p>
                </td>
                <td style="width:34.55pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">N/a</p>
                </td>
                <td style="width:39.55pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">PKR</p>
                </td>
                <td style="width:34.8pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">11.60</p>
                </td>
                <td style="width:34.55pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">N/a</p>
                </td>
                <td style="width:61.05pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:60.05pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Active</p>
                </td>
            </tr>
            <tr style="height:46.6pt;">
                <td style="width:12pt; border-right-style:solid; border-right-width:0.75pt; border-left-style:solid; border-left-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">4</p>
                </td>
                <td style="width:108.9pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">KPCIP-Cons-05 / Communication Specialist<br>(Intermittent Basis)</p>
                </td>
                <td style="width:42.05pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Individual</p>
                </td>
                <td style="width:69.15pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Mr. Tariq Khan Afridi</p>
                </td>
                <td style="width:44.95pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">15-Aug-22</p>
                </td>
                <td style="width:44.65pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">31-Dec-26</p>
                </td>
                <td style="width:34.55pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">N/a</p>
                </td>
                <td style="width:39.55pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">PKR</p>
                </td>
                <td style="width:34.8pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">13.86</p>
                </td>
                <td style="width:34.55pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">N/a</p>
                </td>
                <td style="width:61.05pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:60.05pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Resigned / Financially Closed / re- advertised</p>
                </td>
            </tr>
            <tr style="height:41.6pt;">
                <td style="width:12pt; border-right-style:solid; border-right-width:0.75pt; border-left-style:solid; border-left-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">5</p>
                </td>
                <td style="width:108.9pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">KPCIP-Cons-05 / Environment Specialist &ndash; CIU Abbottabad</p>
                </td>
                <td style="width:42.05pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Individual</p>
                </td>
                <td style="width:69.15pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Sadaf Iqbal</p>
                </td>
                <td style="width:44.95pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">19-Jun-23</p>
                </td>
                <td style="width:44.65pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">31-Dec-26</p>
                </td>
                <td style="width:34.55pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">N/a</p>
                </td>
                <td style="width:39.55pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">PKR</p>
                </td>
                <td style="width:34.8pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">9.34</p>
                </td>
                <td style="width:34.55pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">N/a</p>
                </td>
                <td style="width:61.05pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:60.05pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Active</p>
                </td>
            </tr>
            <tr style="height:42.15pt;">
                <td style="width:12pt; border-right-style:solid; border-right-width:0.75pt; border-left-style:solid; border-left-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">6</p>
                </td>
                <td style="width:108.9pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">KPCIP-Cons-05 / Environment Specialist &ndash; CIU Kohat</p>
                </td>
                <td style="width:42.05pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Individual</p>
                </td>
                <td style="width:69.15pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Tayyaba Akhtar</p>
                </td>
                <td style="width:44.95pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">19-Jun-23</p>
                </td>
                <td style="width:44.65pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">31-Dec-26</p>
                </td>
                <td style="width:34.55pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">N/a</p>
                </td>
                <td style="width:39.55pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">PKR</p>
                </td>
                <td style="width:34.8pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">5.28</p>
                </td>
                <td style="width:34.55pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">N/a</p>
                </td>
                <td style="width:61.05pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:60.05pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Active</p>
                </td>
            </tr>
            <tr style="height:69pt;">
                <td style="width:12pt; border-right-style:solid; border-right-width:0.75pt; border-left-style:solid; border-left-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">7</p>
                </td>
                <td style="width:108.9pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">KPCIP-Cons-05 / Environment Specialist &ndash; CIU Mardan</p>
                </td>
                <td style="width:42.05pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Individual</p>
                </td>
                <td style="width:69.15pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Sahibzada Tanzeel Ahmed</p>
                </td>
                <td style="width:44.95pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">19-Jun-23</p>
                </td>
                <td style="width:44.65pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">31-Dec-26</p>
                </td>
                <td style="width:34.55pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">N/a</p>
                </td>
                <td style="width:39.55pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">PKR</p>
                </td>
                <td style="width:34.8pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">10.66</p>
                </td>
                <td style="width:34.55pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">N/a</p>
                </td>
                <td style="width:61.05pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:60.05pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Active</p>
                </td>
            </tr>
            <tr style="height:41.2pt;">
                <td style="width:12pt; border-right-style:solid; border-right-width:0.75pt; border-left-style:solid; border-left-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">8</p>
                </td>
                <td style="width:108.9pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">KPCIP-Cons-05 / Environment Specialist &ndash; CIU Peshawar</p>
                </td>
                <td style="width:42.05pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Individual</p>
                </td>
                <td style="width:69.15pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Abdul Wakeel Khan</p>
                </td>
                <td style="width:44.95pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">19-Jun-23</p>
                </td>
                <td style="width:44.65pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">31-Dec-26</p>
                </td>
                <td style="width:34.55pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">N/a</p>
                </td>
                <td style="width:39.55pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">PKR</p>
                </td>
                <td style="width:34.8pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">6.44</p>
                </td>
                <td style="width:34.55pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">N/a</p>
                </td>
                <td style="width:61.05pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:60.05pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Active</p>
                </td>
            </tr>
            <tr style="height:48.85pt;">
                <td style="width:12pt; border-right-style:solid; border-right-width:0.75pt; border-left-style:solid; border-left-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">9</p>
                </td>
                <td style="width:108.9pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">KPCIP-Cons-05 / Environment Specialist &ndash; CIU Swat</p>
                </td>
                <td style="width:42.05pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Individual</p>
                </td>
                <td style="width:69.15pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Abdul Hadi</p>
                </td>
                <td style="width:44.95pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">19-Jun-23</p>
                </td>
                <td style="width:44.65pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">31-Dec-26</p>
                </td>
                <td style="width:34.55pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">N/a</p>
                </td>
                <td style="width:39.55pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">PKR</p>
                </td>
                <td style="width:34.8pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">3.17</p>
                </td>
                <td style="width:34.55pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">N/a</p>
                </td>
                <td style="width:61.05pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:60.05pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Active</p>
                </td>
            </tr>
            <tr style="height:48.9pt;">
                <td style="width:12pt; border-right-style:solid; border-right-width:0.75pt; border-left-style:solid; border-left-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">10</p>
                </td>
                <td style="width:108.9pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">KPCIP-Cons-05 / Social Safeguard Specialist &ndash; CIU Abbottabad</p>
                </td>
                <td style="width:42.05pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Individual</p>
                </td>
                <td style="width:69.15pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Muhammad Waqar Saleem</p>
                </td>
                <td style="width:44.95pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">19-Jun-23</p>
                </td>
                <td style="width:44.65pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">31-Dec-26</p>
                </td>
                <td style="width:34.55pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">N/a</p>
                </td>
                <td style="width:39.55pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">PKR</p>
                </td>
                <td style="width:34.8pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">10.66</p>
                </td>
                <td style="width:34.55pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">N/a</p>
                </td>
                <td style="width:61.05pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:60.05pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Active</p>
                </td>
            </tr>
            <tr style="height:69pt;">
                <td style="width:12pt; border-right-style:solid; border-right-width:0.75pt; border-left-style:solid; border-left-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">11</p>
                </td>
                <td style="width:108.9pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">KPCIP-Cons-05 / Social Safeguard Specialist &ndash; CIU Kohat</p>
                </td>
                <td style="width:42.05pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Individual</p>
                </td>
                <td style="width:69.15pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Muhammad Waqar Saleem</p>
                </td>
                <td style="width:44.95pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">19-Jun-23</p>
                </td>
                <td style="width:44.65pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">31-Dec-26</p>
                </td>
                <td style="width:34.55pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">N/a N/a</p>
                </td>
                <td style="width:39.55pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">PKR</p>
                </td>
                <td style="width:34.8pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">10.66</p>
                </td>
                <td style="width:34.55pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">N/a</p>
                </td>
                <td style="width:61.05pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:60.05pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Active</p>
                </td>
            </tr>
            <tr style="height:69pt;">
                <td style="width:12pt; border-right-style:solid; border-right-width:0.75pt; border-left-style:solid; border-left-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">12</p>
                </td>
                <td style="width:108.9pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">KPCIP-Cons-05 / Social Safeguard Specialist &ndash; CIU Mardan</p>
                </td>
                <td style="width:42.05pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Individual</p>
                </td>
                <td style="width:69.15pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Akmal Khan</p>
                </td>
                <td style="width:44.95pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">19-Jun-23</p>
                </td>
                <td style="width:44.65pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">31-Dec-26</p>
                </td>
                <td style="width:34.55pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">N/a</p>
                </td>
                <td style="width:39.55pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">PKR</p>
                </td>
                <td style="width:34.8pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">4.85</p>
                </td>
                <td style="width:34.55pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">N/a</p>
                </td>
                <td style="width:61.05pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:60.05pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Active</p>
                </td>
            </tr>
            <tr style="height:69pt;">
                <td style="width:12pt; border-right-style:solid; border-right-width:0.75pt; border-left-style:solid; border-left-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">13</p>
                </td>
                <td style="width:108.9pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">KPCIP-Cons-05 / Social Safeguard Specialist &ndash; CIU Peshawar</p>
                </td>
                <td style="width:42.05pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Individual</p>
                </td>
                <td style="width:69.15pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;Sehrish Ashraf</p>
                </td>
                <td style="width:44.95pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">19-Jun-23</p>
                </td>
                <td style="width:44.65pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">31-Dec-26</p>
                </td>
                <td style="width:34.55pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">N/a</p>
                </td>
                <td style="width:39.55pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">PKR</p>
                </td>
                <td style="width:34.8pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">5.91</p>
                </td>
                <td style="width:34.55pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">N/a</p>
                </td>
                <td style="width:61.05pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:60.05pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Active</p>
                </td>
            </tr>
            <tr style="height:69pt;">
                <td style="width:12pt; border-right-style:solid; border-right-width:0.75pt; border-left-style:solid; border-left-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">14</p>
                </td>
                <td style="width:108.9pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">KPCIP-Cons-05 / Social Safeguard Specialist &ndash; CIU Swat</p>
                </td>
                <td style="width:42.05pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Individual</p>
                </td>
                <td style="width:69.15pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Saeed Hussain</p>
                </td>
                <td style="width:44.95pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">19-Jun-23</p>
                </td>
                <td style="width:44.65pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">31-Dec-26</p>
                </td>
                <td style="width:34.55pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">N/a</p>
                </td>
                <td style="width:39.55pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">PKR</p>
                </td>
                <td style="width:34.8pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">10.66</p>
                </td>
                <td style="width:34.55pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">N/a</p>
                </td>
                <td style="width:61.05pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:60.05pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Active</p>
                </td>
            </tr>
            <tr style="height:13.8pt;">
                <td colspan="12" style="width:705.05pt; border-right-style:solid; border-right-width:1pt; border-left-style:solid; border-left-width:1pt; padding-right:4.9pt; padding-left:4.9pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;"><strong>B.</strong><strong>&nbsp;&nbsp;</strong><strong>ADF Grant financed Consultants&nbsp;</strong></p>
                </td>
            </tr>
            <tr style="height:41.4pt;">
                <td style="width:12pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">1</p>
                </td>
                <td style="width:108.9pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">KPCIP-Cons-06 / Research Specialist<br>(Intermittent Basis)</p>
                </td>
                <td style="width:42.05pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Individual</p>
                </td>
                <td style="width:69.15pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Mr. Shakeel Hayat</p>
                </td>
                <td style="width:44.95pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">15-Aug-22</p>
                </td>
                <td style="width:44.65pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">31-Dec-26</p>
                </td>
                <td style="width:34.55pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">N/a</p>
                </td>
                <td style="width:39.55pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">PKR</p>
                </td>
                <td style="width:34.8pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">27.50</p>
                </td>
                <td style="width:34.55pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">N/a</p>
                </td>
                <td style="width:61.05pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:60.05pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Active</p>
                </td>
            </tr>
            <tr style="height:69pt;">
                <td style="width:12pt; border-right-style:solid; border-right-width:0.75pt; border-left-style:solid; border-left-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">2</p>
                </td>
                <td style="width:108.9pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">KPCIP-Cons-06 / Capacity Development Specialist - Gender &amp; Social Inclusion GESI (WASH &amp; SWM) (Intermittent Basis)</p>
                </td>
                <td style="width:42.05pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Individual</p>
                </td>
                <td style="width:69.15pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Ms. Noor Mahal</p>
                </td>
                <td style="width:44.95pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">15-Aug-22</p>
                </td>
                <td style="width:44.65pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">31-Dec-26</p>
                </td>
                <td style="width:34.55pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">N/a</p>
                </td>
                <td style="width:39.55pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">PKR</p>
                </td>
                <td style="width:34.8pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">11.66</p>
                </td>
                <td style="width:34.55pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">N/a</p>
                </td>
                <td style="width:61.05pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:60.05pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Active</p>
                </td>
            </tr>
            <tr style="height:69pt;">
                <td style="width:12pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">3</p>
                </td>
                <td style="width:108.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">KPCIP-Cons-06 / Community Engagement &amp; Behavioral Change Specialist<br>(Intermittent Basis)</p>
                </td>
                <td style="width:42.05pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Individual</p>
                </td>
                <td style="width:69.15pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Mr. Sufi Ahmad Owais</p>
                </td>
                <td style="width:44.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">15-Aug-22</p>
                </td>
                <td style="width:44.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">31-Dec-26</p>
                </td>
                <td style="width:34.55pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">N/a</p>
                </td>
                <td style="width:39.55pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">PKR</p>
                </td>
                <td style="width:34.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">9.62</p>
                </td>
                <td style="width:34.55pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">N/a</p>
                </td>
                <td style="width:61.05pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:60.05pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Active</p>
                </td>
            </tr>
            <tr style="height:69pt;">
                <td style="width:12pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">4</p>
                </td>
                <td style="width:108.9pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">KPCIP-Cons-06 / Skills &amp; Enterprise Development Specialist<br>(Intermittent Basis)</p>
                </td>
                <td style="width:42.05pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Individual</p>
                </td>
                <td style="width:69.15pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Mr. Sarmad Hussain Khan</p>
                </td>
                <td style="width:44.95pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">15-Aug-22</p>
                </td>
                <td style="width:44.65pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">31-Dec-26</p>
                </td>
                <td style="width:34.55pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">N/a</p>
                </td>
                <td style="width:39.55pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">PKR</p>
                </td>
                <td style="width:34.8pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">27.50</p>
                </td>
                <td style="width:34.55pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">N/a</p>
                </td>
                <td style="width:61.05pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:60.05pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Resigned / Financially Closed / re-advertised.&nbsp; Contact issued in First week of July</p>
                </td>
            </tr>
            <tr style="height:69pt;">
                <td style="width:12pt; border-right-style:solid; border-right-width:0.75pt; border-left-style:solid; border-left-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:108.9pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Skills &amp; Enterprise Development Specialist</p>
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">(Intermittent Basis)</p>
                </td>
                <td style="width:42.05pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Individual</p>
                </td>
                <td style="width:69.15pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Zahir Khurshid</p>
                </td>
                <td style="width:44.95pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">3-July-23</p>
                </td>
                <td style="width:44.65pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:34.55pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:39.55pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:34.8pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:34.55pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:61.05pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:60.05pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Active</p>
                </td>
            </tr>
            <tr style="height:69pt;">
                <td style="width:12pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">5</p>
                </td>
                <td style="width:108.9pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">KPCIP-Cons-06 / Scholarships Programme Specialist<br>(Intermittent Basis)</p>
                </td>
                <td style="width:42.05pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Individual</p>
                </td>
                <td style="width:69.15pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Mr. Fayyaz Ali Khan</p>
                </td>
                <td style="width:44.95pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">15-Aug-22</p>
                </td>
                <td style="width:44.65pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">31-Dec-26</p>
                </td>
                <td style="width:34.55pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">N/a</p>
                </td>
                <td style="width:39.55pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">PKR</p>
                </td>
                <td style="width:34.8pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">25.92</p>
                </td>
                <td style="width:34.55pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">N/a</p>
                </td>
                <td style="width:61.05pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:60.05pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Resigned / Financially Closed / re-advertised. Contact issued in First week of July</p>
                </td>
            </tr>
            <tr style="height:69pt;">
                <td style="width:12pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:108.9pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Scholarships Programme Specialist</p>
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">(Intermittent Basis)</p>
                </td>
                <td style="width:42.05pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Individual</p>
                </td>
                <td style="width:69.15pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Danish Latif</p>
                </td>
                <td style="width:44.95pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">3-July-23</p>
                </td>
                <td style="width:44.65pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:34.55pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:39.55pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:34.8pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:34.55pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:61.05pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:60.05pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Active</p>
                </td>
            </tr>
        </tbody>
    </table>
    
    <table cellspacing="0" cellpadding="0" style="width:954pt; margin-right:9pt; margin-left:9pt; border-collapse:collapse; float:left;">
        <thead>
            <tr>
                <td colspan="12" style="width:712.15pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.4pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:11pt;"><strong>Table A5.2: Works, Goods, and Non-Consulting Services Contracts Awarded Under the Project</strong></p>
                </td>
            </tr>
            <tr>
                <td rowspan="3" style="width:65.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; font-size:9pt;"><strong>Package No.</strong></p>
                </td>
                <td rowspan="3" style="width:63.35pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; font-size:9pt;"><strong>Name of Contract</strong></p>
                </td>
                <td rowspan="3" style="width:55.4pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Contractor/</strong></p>
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Supplier</strong></p>
                </td>
                <td rowspan="3" style="width:40.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Contract Type</strong></p>
                </td>
                <td rowspan="3" style="width:37.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; font-size:9pt;"><strong>Contract Award Date</strong></p>
                </td>
                <td colspan="2" style="width:80.55pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; font-size:9pt;"><strong>Completion date</strong></p>
                </td>
                <td rowspan="3" style="width:39.5pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; font-size:9pt;"><strong>Currency&nbsp;</strong></p>
                </td>
                <td colspan="2" rowspan="2" style="width:83.25pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Contract Amount (million) PKR</strong></p>
                </td>
                <td rowspan="3" style="width:48.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Expenditure (MA+IPC&apos;s) in million.</strong></p>
                </td>
                <td rowspan="3" style="width:99.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; font-size:9pt;"><strong>Contract Status&nbsp;</strong><strong><span style="font-size:6pt;"><sup>d</sup></span></strong></p>
                </td>
            </tr>
            <tr style="height:22pt;">
                <td rowspan="2" style="width:34.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Original</strong></p>
                </td>
                <td rowspan="2" style="width:34.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Revised&nbsp;</strong><strong><span style="font-size:6pt;"><sup>b</sup></span></strong></p>
                </td>
            </tr>
            <tr style="height:2.3pt;">
                <td style="width:37.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:bottom; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Original</strong></p>
                </td>
                <td style="width:34.5pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Revised</strong></p>
                </td>
            </tr>
            <tr>
                <td style="width:65.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:63.35pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:55.4pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:40.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:37.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:34.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:34.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:39.5pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:37.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:34.5pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:48.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:99.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td style="width:65.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">CW-01, Lot-1: ABBOTTABAD.</p>
                </td>
                <td rowspan="5" style="width:63.35pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Urban Green Space Initiatives</p>
                </td>
                <td style="width:55.4pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">M/s Reliable-JHK (JV)</p>
                </td>
                <td rowspan="13" style="width:40.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Works</p>
                </td>
                <td style="width:37.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">27-Jun-22</p>
                </td>
                <td style="width:34.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">19-Apr-24</p>
                </td>
                <td style="width:34.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:39.5pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:37.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">1174.98</p>
                </td>
                <td style="width:34.5pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:48.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">281</p>
                </td>
                <td style="width:99.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-indent:0.5pt; font-size:9pt;">Active</p>
                </td>
            </tr>
            <tr>
                <td style="width:65.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">CW-01, Lot-2: KOHAT.</p>
                </td>
                <td style="width:55.4pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">M/s Reliable-JHK (JV)</p>
                </td>
                <td style="width:37.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">27-Jun-22</p>
                </td>
                <td style="width:34.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">27-Oct-23</p>
                </td>
                <td style="width:34.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:39.5pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:37.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">389.95</p>
                </td>
                <td style="width:34.5pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:48.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">139</p>
                </td>
                <td style="width:99.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; font-size:9pt;">Active</p>
                </td>
            </tr>
            <tr>
                <td style="width:65.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">CW-01, Lot-3: MARDAN.</p>
                </td>
                <td style="width:55.4pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">M/s Reliable-JHK (JV)</p>
                </td>
                <td style="width:37.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">27-Jun-22</p>
                </td>
                <td style="width:34.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">15 Months</p>
                </td>
                <td style="width:34.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:39.5pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:37.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">582.64</p>
                </td>
                <td style="width:34.5pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:48.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">87.4</p>
                </td>
                <td style="width:99.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; font-size:9pt;">PD-KPCIP has agreed to this termination for convenience and has shared it with ADB for approval.</p>
                </td>
            </tr>
            <tr>
                <td style="width:65.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">CW-01, Lot-4: MINGORA.</p>
                </td>
                <td style="width:55.4pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">M/s Reliable-JHK (JV)</p>
                </td>
                <td style="width:37.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">27-Jun-22</p>
                </td>
                <td style="width:34.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">07-Nov-23</p>
                </td>
                <td style="width:34.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:39.5pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:37.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">287.98</p>
                </td>
                <td style="width:34.5pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:48.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">43</p>
                </td>
                <td style="width:99.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; font-size:9pt;">Active</p>
                </td>
            </tr>
            <tr>
                <td style="width:65.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">CW-01, Lot-5: PESHAWAR.</p>
                </td>
                <td style="width:55.4pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">M/s Reliable-JHK (JV)</p>
                </td>
                <td style="width:37.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">27-Jun-22</p>
                </td>
                <td style="width:34.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">19-Apr-24</p>
                </td>
                <td style="width:34.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:39.5pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:37.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">1056.66</p>
                </td>
                <td style="width:34.5pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:48.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">376</p>
                </td>
                <td style="width:99.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; font-size:9pt;">Active</p>
                </td>
            </tr>
            <tr>
                <td style="width:65.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">CW-02, Lot-1: ABBOTTABAD.</p>
                </td>
                <td style="width:63.35pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Rehabilitation &amp; Upgrade of the Water Supply System</p>
                </td>
                <td style="width:55.4pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">ZKB-TTSH-INSAAT (JV)</p>
                </td>
                <td style="width:37.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">22-March--2023<span style="color:#ff0000;">&nbsp;</span></p>
                </td>
                <td style="width:34.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">36 Months</p>
                </td>
                <td style="width:34.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:39.5pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:37.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">8503.65</p>
                </td>
                <td style="width:34.5pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:48.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">1275.5</p>
                </td>
                <td style="width:99.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; font-size:9pt;">Active</p>
                </td>
            </tr>
            <tr>
                <td style="width:65.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">CW-02, Lot-2: ABBOTTABAD.</p>
                </td>
                <td style="width:63.35pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">New Water Treatment Plant</p>
                </td>
                <td style="width:55.4pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">ZKB-TTSH-INSAAT (JV)</p>
                </td>
                <td style="width:37.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">08-Nov-22</p>
                </td>
                <td style="width:34.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">07-Nov-25</p>
                </td>
                <td style="width:34.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:39.5pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:37.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">2596.19</p>
                </td>
                <td style="width:34.5pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:48.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">0</p>
                </td>
                <td style="width:99.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; font-size:9pt;">Active</p>
                </td>
            </tr>
            <tr>
                <td style="width:65.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">CW-02, Lot-3: KOHAT.</p>
                </td>
                <td style="width:63.35pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Rehabilitation &amp; Upgrade of the Water Supply System</p>
                </td>
                <td style="width:55.4pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">ZKB-TTSH-INSAAT (JV)</p>
                </td>
                <td style="width:37.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">08-Nov-22</p>
                </td>
                <td style="width:34.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">19-Jul-25</p>
                </td>
                <td style="width:34.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:39.5pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:37.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">4646.93</p>
                </td>
                <td style="width:34.5pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:48.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">697</p>
                </td>
                <td style="width:99.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; font-size:9pt;">Active</p>
                </td>
            </tr>
            <tr>
                <td style="width:65.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">CW-02, Lot-4: PESHAWAR.</p>
                </td>
                <td style="width:63.35pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Rehabilitation &amp; Upgrade of the Water Supply System</p>
                </td>
                <td style="width:55.4pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">ZKB-TTSH-INSAAT (JV)</p>
                </td>
                <td style="width:37.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">08-Nov-22</p>
                </td>
                <td style="width:34.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">30-Jan-25</p>
                </td>
                <td style="width:34.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:39.5pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:37.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">2595.27</p>
                </td>
                <td style="width:34.5pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:48.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">389</p>
                </td>
                <td style="width:99.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; font-size:9pt;">Active</p>
                </td>
            </tr>
            <tr>
                <td style="width:65.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">CW-03, Lot-1: KOHAT.</p>
                </td>
                <td style="width:63.35pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">STP</p>
                </td>
                <td style="width:55.4pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">ES BAKU-JHK (JV)</p>
                </td>
                <td style="width:37.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">03-Oct-22</p>
                </td>
                <td style="width:34.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">02-Oct-25</p>
                </td>
                <td style="width:34.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:39.5pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:37.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">6731.94</p>
                </td>
                <td style="width:34.5pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:48.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">1010</p>
                </td>
                <td style="width:99.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; font-size:9pt;">Active</p>
                </td>
            </tr>
            <tr>
                <td style="width:65.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">CW-03, Lot-2: MARDAN.</p>
                </td>
                <td style="width:63.35pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">STP</p>
                </td>
                <td style="width:55.4pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">MATRACON-SWCCG (JV)</p>
                </td>
                <td style="width:37.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">04-Nov-22</p>
                </td>
                <td style="width:34.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">03-Nov-25</p>
                </td>
                <td style="width:34.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:39.5pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:37.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">8313.86</p>
                </td>
                <td style="width:34.5pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:48.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">1247</p>
                </td>
                <td style="width:99.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; font-size:9pt;">Active</p>
                </td>
            </tr>
            <tr>
                <td style="width:65.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">CW-04, Lot-1: MINGORA.</p>
                </td>
                <td style="width:63.35pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">New Water Treatment Plant</p>
                </td>
                <td style="width:55.4pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">-</p>
                </td>
                <td style="width:37.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:34.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:34.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:39.5pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:37.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">3405</p>
                </td>
                <td style="width:34.5pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:48.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">0</p>
                </td>
                <td style="width:99.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; font-size:9pt;">Technical evaluation report is submitted to ADB for concurrence.</p>
                </td>
            </tr>
            <tr>
                <td style="width:65.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">CW-04, Lot-2: MINGORA.</p>
                </td>
                <td style="width:63.35pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Rehabilitation &amp; Upgrade of Water Supply System</p>
                </td>
                <td style="width:55.4pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">ZKB-TTSH-INSAAT (JV)</p>
                </td>
                <td style="width:37.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">29-Nov-22</p>
                </td>
                <td style="width:34.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">30-Jan-26</p>
                </td>
                <td style="width:34.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:39.5pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:37.95pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">20328.31</p>
                </td>
                <td style="width:34.5pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:48.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; text-align:center; font-size:9pt;">3049</p>
                </td>
                <td style="width:99.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-right:1.55pt; margin-bottom:0pt; font-size:9pt;">Active</p>
                </td>
            </tr>
        </tbody>
    </table>
    
</div>
<p><br style="page-break-before:always; clear:both; mso-break-type:section-break;"></p>
<div>
    <h2 style="margin-top:0pt; margin-left:53.5pt; margin-bottom:12pt; text-indent:-18pt; text-align:left; font-size:11pt;">ii)<span style="width:8.22pt; font:7pt 'Times New Roman'; display:inline-block;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><a name="_Toc148522788">Appendix-6: Pipeline Contracts &ndash; To Be Awarded under The Project</a></h2>
    <table cellspacing="0" cellpadding="0" style="width:730.05pt; margin-right:9pt; margin-left:9pt; border-collapse:collapse; float:left;">
        <thead>
            <tr style="height:7.15pt;">
                <td colspan="13" style="width:719.25pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.4pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:11pt;"><strong>Table A6.1: Works, Goods and Non-consulting Services Contracts through Open Competitive Bidding Single Stage-Two Envelope</strong></p>
                </td>
            </tr>
            <tr style="height:7.15pt;">
                <td rowspan="2" style="width:38.85pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;"><strong>Package/ Lot # as in PP</strong></p>
                </td>
                <td rowspan="2" style="width:109.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;"><strong>Name of Contract Package</strong></p>
                </td>
                <td rowspan="2" style="width:38.85pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;"><strong>Est. Amt.</strong></p>
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;"><strong>($ million)</strong></p>
                </td>
                <td rowspan="2" style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;"><strong>Planned/ Approved</strong></p>
                </td>
                <td colspan="8" style="width:364.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;"><strong>Milestone Dates</strong></p>
                </td>
                <td rowspan="2" style="width:67.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;"><strong>Remarks</strong></p>
                </td>
            </tr>
            <tr style="height:7.15pt;">
                <td style="width:24.6pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;"><strong>IFB</strong></p>
                </td>
                <td style="width:38.85pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Technical Bid Opening</strong></p>
                </td>
                <td style="width:24.6pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>TBER to ADB</strong></p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>ADB Approval</strong></p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Financial Bid opening</strong></p>
                </td>
                <td style="width:31.75pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>PBER to ADB</strong></p>
                </td>
                <td style="width:38.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>ADB approval</strong></p>
                </td>
                <td style="width:38.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Contract Award</strong></p>
                </td>
            </tr>
            <tr style="height:7.95pt;">
                <td style="width:38.85pt; border-top-style:solid; border-top-width:0.75pt; border-left-style:solid; border-left-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.4pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;"><strong>&nbsp;</strong></p>
                </td>
                <td style="width:109.65pt; border-top-style:solid; border-top-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.4pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:38.85pt; border-top-style:solid; border-top-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.4pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:45.9pt; border-top-style:solid; border-top-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.4pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:24.6pt; border-top-style:solid; border-top-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.4pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:38.85pt; border-top-style:solid; border-top-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.4pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:24.6pt; border-top-style:solid; border-top-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.4pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:45.9pt; border-top-style:solid; border-top-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.4pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:45.9pt; border-top-style:solid; border-top-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.4pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:31.75pt; border-top-style:solid; border-top-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.4pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:38.8pt; border-top-style:solid; border-top-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.4pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:38.8pt; border-top-style:solid; border-top-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.4pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:67.2pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
        </thead>
        <tbody>
            <tr style="height:19.5pt;">
                <td rowspan="2" style="width:38.85pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">CW-05:</p>
                </td>
                <td rowspan="2" style="width:109.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Procurement, Supply, Installation, commissioning and operations of Solid waste management system MARDAN</p>
                </td>
                <td rowspan="2" style="width:38.85pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">24.87</p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Planned</p>
                </td>
                <td style="width:24.6pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q3-2023</p>
                </td>
                <td style="width:38.85pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q4-2023</p>
                </td>
                <td style="width:24.6pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q4-2023</p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q4-2023</p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q4-2023</p>
                </td>
                <td style="width:31.75pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Q4-2023</p>
                </td>
                <td style="width:38.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q4-2023</p>
                </td>
                <td style="width:38.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q4-2023</p>
                </td>
                <td style="width:67.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
            <tr style="height:7.15pt;">
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Actual</p>
                </td>
                <td style="width:24.6pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:38.85pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:24.6pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:31.75pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:38.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:38.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:67.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
            <tr style="height:34.35pt;">
                <td rowspan="2" style="width:38.85pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">CW-06:</p>
                </td>
                <td rowspan="2" style="width:109.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Construction of Urban / Green Spaces &ndash; Salhad Bagh, ABBOTTABAD</p>
                </td>
                <td rowspan="2" style="width:38.85pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">5.44</p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Planned</p>
                </td>
                <td style="width:24.6pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q3-2026</p>
                </td>
                <td style="width:38.85pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q3-2026</p>
                </td>
                <td style="width:24.6pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q3-2026</p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q3-2026</p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q4-2026</p>
                </td>
                <td style="width:31.75pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Q4-2026</p>
                </td>
                <td style="width:38.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q4-2026</p>
                </td>
                <td style="width:38.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q4-2026</p>
                </td>
                <td rowspan="2" style="width:67.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Once the CW-07 is near to completion, the procurement will start for CW-06</p>
                </td>
            </tr>
            <tr style="height:7.15pt;">
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Actual</p>
                </td>
                <td style="width:24.6pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:38.85pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:24.6pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:31.75pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:38.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:38.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
            <tr style="height:19.05pt;">
                <td rowspan="2" style="width:38.85pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">CW-07: Lot-1</p>
                </td>
                <td rowspan="2" style="width:109.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Procurement, Supply, Installation, commissioning and operations of Solid waste management system PESHAWAR</p>
                </td>
                <td rowspan="2" style="width:38.85pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">77.11</p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Planned</p>
                </td>
                <td style="width:24.6pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q2-2023</p>
                </td>
                <td style="width:38.85pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q3-2023</p>
                </td>
                <td style="width:24.6pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q3-2023</p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q4-2023</p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q4-2023</p>
                </td>
                <td style="width:31.75pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Q4-2023</p>
                </td>
                <td style="width:38.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q4-2023</p>
                </td>
                <td style="width:38.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q4-2023</p>
                </td>
                <td style="width:67.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
            <tr style="height:7.15pt;">
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Actual</p>
                </td>
                <td style="width:24.6pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:38.85pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:24.6pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:31.75pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:38.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:38.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:67.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
            <tr style="height:19.95pt;">
                <td rowspan="2" style="width:38.85pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">CW-07: Lot-2</p>
                </td>
                <td rowspan="2" style="width:109.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Procurement, Supply, Installation, commissioning and operations of Solid waste management system KOHAT</p>
                </td>
                <td rowspan="2" style="width:38.85pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">23.60</p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Planned</p>
                </td>
                <td style="width:24.6pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q2-2023</p>
                </td>
                <td style="width:38.85pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q3-2023</p>
                </td>
                <td style="width:24.6pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q3-2023</p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q4-2023</p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q4-2023</p>
                </td>
                <td style="width:31.75pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Q4-2023</p>
                </td>
                <td style="width:38.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q4-2023</p>
                </td>
                <td style="width:38.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q4-2023</p>
                </td>
                <td style="width:67.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
            <tr style="height:7.15pt;">
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Actual</p>
                </td>
                <td style="width:24.6pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:38.85pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:24.6pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:31.75pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:38.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:38.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:67.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
            <tr style="height:39.75pt;">
                <td rowspan="2" style="width:38.85pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">CW-07: Lot-3</p>
                </td>
                <td rowspan="2" style="width:109.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Procurement, Supply, Installation, commissioning and operations of Solid waste management system MINGORA</p>
                </td>
                <td rowspan="2" style="width:38.85pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">13.45</p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Planned</p>
                </td>
                <td style="width:24.6pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:38.85pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:24.6pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:31.75pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:38.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:38.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td rowspan="2" style="width:67.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">The sub-project will be shifted to some other site as the current site is not feasible &ndash; GoKP to decide.</p>
                </td>
            </tr>
            <tr style="height:7.15pt;">
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Actual</p>
                </td>
                <td style="width:24.6pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:38.85pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:24.6pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:31.75pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:38.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:38.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
            <tr style="height:28.95pt;">
                <td rowspan="2" style="width:38.85pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">CW-07: Lot-4</p>
                </td>
                <td rowspan="2" style="width:109.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">CW-07: Procurement, Supply, Installation, commissioning and operations of Solid waste management system ABBOTABAD</p>
                </td>
                <td rowspan="2" style="width:38.85pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">24.04</p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Planned</p>
                </td>
                <td style="width:24.6pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q2-2023</p>
                </td>
                <td style="width:38.85pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q3-2023</p>
                </td>
                <td style="width:24.6pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q3-2023</p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q4-2023</p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q4-2023</p>
                </td>
                <td style="width:31.75pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q4-2023</p>
                </td>
                <td style="width:38.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q4-2023</p>
                </td>
                <td style="width:38.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q4-2023</p>
                </td>
                <td style="width:67.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
            <tr style="height:7.15pt;">
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Actual</p>
                </td>
                <td style="width:24.6pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:38.85pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:24.6pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:31.75pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:38.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:38.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:67.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
        </tbody>
    </table>
    
    <table cellspacing="0" cellpadding="0" style="width:954pt; margin-right:9pt; margin-left:9pt; border-collapse:collapse; float:left;">
        <thead>
            <tr style="height:50.9pt;">
                <td colspan="10" style="border-bottom-style:solid; border-bottom-width:0.75pt;">
                    <p style="margin:0pt 29.45pt 0pt 29.5pt; text-align:center; widows:0; orphans:0; font-size:11pt;"><strong>Procurement Contracts Monitoring Sheet</strong></p>
                    <p style="margin:0pt 29.45pt 0pt 29.5pt; text-align:center; widows:0; orphans:0; font-size:11pt;"><strong>Table A6.2: Works and Goods through Shopping</strong></p>
                    <p style="margin:0pt 29.45pt 0pt 29.5pt; text-align:center; widows:0; orphans:0; font-size:11pt;"><strong>(Prior Review)</strong></p>
                </td>
            </tr>
            <tr style="height:14.75pt;">
                <td rowspan="2" style="border-style:solid; border-width:0.75pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Package No.</strong></p>
                </td>
                <td rowspan="2" style="border-style:solid; border-width:0.75pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Name of Contract Package</strong></p>
                </td>
                <td rowspan="2" style="border-style:solid; border-width:0.75pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Estimated amount (PKR)</strong></p>
                </td>
                <td rowspan="2" style="border-style:solid; border-width:0.75pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Date type</strong></p>
                </td>
                <td colspan="5" style="border-style:solid; border-width:0.75pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Milestone Dates a</strong></p>
                </td>
                <td rowspan="2" style="border-style:solid; border-width:0.75pt; background-color:#f2f2f2;">
                    <p style="margin:0.35pt 3.75pt 0pt 4.1pt; text-align:center; line-height:114%; widows:0; orphans:0; font-size:9pt;"><strong>Remarks</strong></p>
                </td>
            </tr>
            <tr style="height:48.1pt;">
                <td style="border-style:solid; border-width:0.75pt; background-color:#f2f2f2;">
                    <p style="margin:0.35pt 4.75pt 0pt 5.85pt; text-indent:-0.85pt; text-align:center; line-height:114%; widows:0; orphans:0; font-size:9pt;"><strong>RFQs advertised</strong></p>
                </td>
                <td style="border-style:solid; border-width:0.75pt; background-color:#f2f2f2;">
                    <p style="margin:0.35pt 3.75pt 0pt 4.1pt; text-align:center; line-height:114%; widows:0; orphans:0; font-size:9pt;"><strong>Evaluation Report to ADB.</strong></p>
                </td>
                <td style="border-style:solid; border-width:0.75pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-right:1.7pt; margin-bottom:0pt; text-align:center; widows:0; orphans:0; font-size:9pt;"><strong>ADB approval</strong></p>
                </td>
                <td style="border-style:solid; border-width:0.75pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-right:0.95pt; margin-bottom:0pt; text-align:center; widows:0; orphans:0; font-size:9pt;"><strong>Contract Award</strong></p>
                </td>
                <td style="border-style:solid; border-width:0.75pt; background-color:#f2f2f2;">
                    <p style="margin:3.95pt 1.9pt 0pt 3.1pt; text-indent:3.6pt; text-align:center; line-height:114%; widows:0; orphans:0; font-size:9pt;"><strong>Intended Completion</strong></p>
                </td>
            </tr>
            <tr style="height:7.75pt;">
                <td style="border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-left-style:solid; border-left-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-left-style:solid; border-left-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-left-style:solid; border-left-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-left-style:solid; border-left-width:0.75pt;">
                    <p style="margin-top:0.4pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-left-style:solid; border-left-width:0.75pt;">
                    <p style="margin-top:0.4pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-left-style:solid; border-left-width:0.75pt;">
                    <p style="margin-top:0.4pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-left-style:solid; border-left-width:0.75pt;">
                    <p style="margin-top:0.4pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-left-style:solid; border-left-width:0.75pt;">
                    <p style="margin-top:0.4pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-left-style:solid; border-left-width:0.75pt;">
                    <p style="margin-top:0.4pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-left-style:solid; border-left-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
        </thead>
        <tbody>
            <tr style="height:23.15pt;">
                <td rowspan="2" style="border-right-style:solid; border-right-width:0.75pt; border-left-style:solid; border-left-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt;">
                    <p style="margin-top:5.15pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">03A / 01</p>
                </td>
                <td rowspan="2" style="border-right-style:solid; border-right-width:0.75pt; border-left-style:solid; border-left-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; line-height:108%; widows:0; orphans:0; font-size:9pt;">KPCIP - Shopping - Goods: General Office Equipment</p>
                </td>
                <td rowspan="2" style="border-right-style:solid; border-right-width:0.75pt; border-left-style:solid; border-left-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt;">
                    <p style="margin-top:5.15pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">7,605,200</p>
                </td>
                <td style="border-right-style:solid; border-right-width:0.75pt; border-left-style:solid; border-left-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.5pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Planned</p>
                </td>
                <td style="border-right-style:solid; border-right-width:0.75pt; border-left-style:solid; border-left-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:6.2pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Jul-22</p>
                </td>
                <td style="border-right-style:solid; border-right-width:0.75pt; border-left-style:solid; border-left-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">-</p>
                </td>
                <td style="border-right-style:solid; border-right-width:0.75pt; border-left-style:solid; border-left-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:1.7pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Sep-22</p>
                </td>
                <td style="border-right-style:solid; border-right-width:0.75pt; border-left-style:solid; border-left-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">-</p>
                </td>
                <td style="border-right-style:solid; border-right-width:0.75pt; border-left-style:solid; border-left-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">-</p>
                </td>
                <td style="border-right-style:solid; border-right-width:0.75pt; border-left-style:solid; border-left-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
            <tr style="height:33.7pt;">
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.45pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Actual</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:6.3pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">24-Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.85pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">26-Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:1.7pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">27-Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:0.95pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">28-Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.85pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">6-Oct-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
            <tr style="height:23.15pt;">
                <td rowspan="2" style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:5.15pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">03A / 02</p>
                </td>
                <td rowspan="2" style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-left:0.7pt; margin-bottom:0pt; line-height:108%; widows:0; orphans:0; font-size:9pt;">KPCIP - Shopping - Goods: Procurement of General Office Equipment</p>
                </td>
                <td rowspan="2" style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:5.15pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">1,697,850</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.5pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Planned</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:6.2pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Jul-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:1.7pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
            <tr style="height:23.15pt;">
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.45pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Actual</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:6.3pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">27-Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.85pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">28-Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:1.7pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">29-Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:0.95pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">4-Oct-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.85pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">10-Oct-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
            <tr style="height:23.15pt;">
                <td rowspan="2" style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:5.15pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">03B / 01</p>
                </td>
                <td rowspan="2" style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-left:0.7pt; margin-bottom:0pt; line-height:108%; widows:0; orphans:0; font-size:9pt;">KPCIP - Shopping - Goods: Procurement of IT Equipments (PMU)</p>
                </td>
                <td rowspan="2" style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:5.15pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">13,240,000</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.5pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Planned</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:6.2pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Jul-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:1.7pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
            <tr style="height:23.15pt;">
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.45pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Actual</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:6.2pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">4-Nov-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.85pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">6-Nov-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:1.7pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">7-Nov-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:0.95pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">16-Oct-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.85pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">24-Nov-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
            <tr style="height:23.15pt;">
                <td rowspan="2" style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:5.15pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">03B / 02</p>
                </td>
                <td rowspan="2" style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-left:0.7pt; margin-bottom:0pt; line-height:108%; widows:0; orphans:0; font-size:9pt;">KPCIP - Shopping - Goods: Procurement of IT Equipments (CIUS)</p>
                </td>
                <td rowspan="2" style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:5.15pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">15,600,000</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.5pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Planned</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:6.2pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Jul-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:1.7pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
            <tr style="height:23.15pt;">
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.45pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Actual</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:6.2pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">4-Nov-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.85pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">6-Nov-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:1.7pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">7-Nov-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:0.95pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">16-Oct-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.85pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">24-Nov-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
            <tr style="height:23.15pt;">
                <td rowspan="2" style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:5.15pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">03C / 01</p>
                </td>
                <td rowspan="2" style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-left:0.7pt; margin-bottom:0pt; line-height:108%; widows:0; orphans:0; font-size:9pt;">KPCIP - Shopping - Goods: Procurement of Office Furniture</p>
                </td>
                <td rowspan="2" style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:5.15pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">13,540,000</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.5pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Planned</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:6.2pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Jul-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:1.7pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
            <tr style="height:23.15pt;">
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.45pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Actual</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:6.2pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">18-Oct-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.85pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">20-Oct-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:1.7pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">24-Oct-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:0.95pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">31-Oct-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.85pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">4-Nov-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
            <tr style="height:23.15pt;">
                <td rowspan="2" style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:5.15pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">03D / 01</p>
                </td>
                <td rowspan="2" style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-left:0.7pt; margin-bottom:0pt; line-height:108%; widows:0; orphans:0; font-size:9pt;">KPCIP - Shopping - Goods: Procurement &amp; Supply of Vehicles (Mid-Sized Sedan Car with 1.5/1.6 L Engine &amp; Auto Transmission (08 Nos.) for PMU</p>
                </td>
                <td rowspan="2" style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:5.15pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">39,792,000</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.5pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Planned</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:6.2pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Jul-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:1.7pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
            <tr style="height:35.95pt;">
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.45pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Actual</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:6.3pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">27-Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.85pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">28-Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:1.7pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">29-Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:0.95pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">3-Oct-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.85pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">10-Oct-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
            <tr style="height:23.15pt;">
                <td rowspan="2" style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:5.15pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">03D / 02</p>
                </td>
                <td rowspan="2" style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-left:0.7pt; margin-bottom:0pt; line-height:108%; widows:0; orphans:0; font-size:9pt;">KPCIP - Shopping - Goods: Procurement of Motor Bikes</p>
                </td>
                <td rowspan="2" style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:5.15pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">4,491,375</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.5pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Planned</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:6.2pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Jul-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-left:0.2pt; margin-bottom:0pt; text-align:center; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:1.7pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-left:0.3pt; margin-bottom:0pt; text-align:center; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-left:0.25pt; margin-bottom:0pt; text-align:center; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
            <tr style="height:27pt;">
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.45pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Actual</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:6.3pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">27-Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.85pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">28-Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:1.7pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">29-Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:0.95pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">4-Oct-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.85pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">10-Oct-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
            <tr style="height:36.25pt;">
                <td rowspan="2" style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:5.15pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">03D / 03</p>
                </td>
                <td rowspan="2" style="border-style:solid; border-width:0.75pt;">
                    <p style="margin:0pt 0.25pt 0pt 0.7pt; line-height:4.9pt; widows:0; orphans:0;"><span style="font-size:9pt;">KPCIP - Shopping - Goods: Procurement &amp;</span></p>
                    <p style="margin:0.5pt 0.25pt 0pt 0.7pt; line-height:108%; widows:0; orphans:0; font-size:9pt;">Supply of: (I) Vehicle [07 Seater, 05 Door Vehicle &apos;JEEP&apos; (4X4) (2700 to 2800 CC) -</p>
                    <p style="margin:0pt 0.25pt 0pt 0.7pt; line-height:108%; widows:0; orphans:0; font-size:9pt;">Fortuner Legender (01 No.)] AND (II) Mid - Sized Sedan Car with 1.3/1.5 L Engine &amp; Auto Transmission Toyota YARIS ATIV CVT (07 Nos.) for PMU</p>
                </td>
                <td rowspan="2" style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:5.15pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">46,839,000</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.5pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Planned</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:6.2pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Jul-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:1.7pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
            <tr style="height:37.6pt;">
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.45pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Actual</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:6.3pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">27-Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.85pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">28-Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:1.7pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">29-Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:0.95pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">3-Oct-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.85pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">10-Oct-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
            <tr style="height:23.15pt;">
                <td rowspan="2" style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:5.15pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">03D / 04</p>
                </td>
                <td rowspan="2" style="border-style:solid; border-width:0.75pt;">
                    <p style="margin:0pt 0.85pt 0pt 0.7pt; line-height:108%; widows:0; orphans:0; font-size:9pt;">KPCIP - Shopping - Goods: Procurement of Mid - Sized Sedan Car with 1.3/1.5 L Engine &amp; Auto Transmission (10 Nos.) for CIU&apos;s</p>
                </td>
                <td rowspan="2" style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:5.15pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">41,070,000</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.5pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Planned</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:6.2pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Jul-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:1.7pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
            <tr style="height:23.15pt;">
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.45pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Actual</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:6.3pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">27-Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.85pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">28-Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:1.7pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">29-Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:0.95pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">5-Oct-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.85pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">10-Oct-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
            <tr style="height:23.15pt;">
                <td rowspan="2" style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:5.15pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">03D / 05</p>
                </td>
                <td rowspan="2" style="border-style:solid; border-width:0.75pt;">
                    <p style="margin:0pt 0.85pt 0pt 0.7pt; line-height:108%; widows:0; orphans:0; font-size:9pt;">KPCIP - Shopping - Goods: Procurement of Mid - Sized Sedan Car with 1.3/1.5 L Engine &amp; Auto Transmission (08 Nos.) for PMCSC</p>
                </td>
                <td rowspan="2" style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:5.15pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">32,856,000</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.5pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Planned</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:6.2pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Jul-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:1.7pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
            <tr style="height:36.7pt;">
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.45pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Actual</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:6.3pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">27-Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.85pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">28-Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:1.7pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">29-Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:0.95pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">5-Oct-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.85pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">10-Oct-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
            <tr style="height:23.15pt;">
                <td rowspan="2" style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:5.15pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">03D / 06</p>
                </td>
                <td rowspan="2" style="border-style:solid; border-width:0.75pt;">
                    <p style="margin:0pt 0.85pt 0pt 0.7pt; line-height:108%; widows:0; orphans:0; font-size:9pt;">KPCIP - Shopping - Goods: Procurement of Mid - Sized Sedan Car with 1.3/1.5 L Engine &amp; Auto Transmission (09 Nos.) for PMCSC</p>
                </td>
                <td rowspan="2" style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:5.15pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">36,963,000</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.5pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Planned</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:6.2pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Jul-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:1.7pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
            <tr style="height:23.15pt;">
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.45pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Actual</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:6.3pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">27-Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.85pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">28-Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:1.7pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">29-Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:0.95pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">5-Oct-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.85pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">10-Oct-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
        </tbody>
    </table>
   
    <table cellspacing="0" cellpadding="0" style="width:954pt; margin-right:9pt; margin-left:9pt; border-collapse:collapse; float:left;">
        <thead>
            <tr style="height:11.65pt;">
                <td colspan="9" style="width:719.25pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.4pt; padding-left:5.4pt; vertical-align:bottom;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:10pt;"><strong>Table A6.3:</strong><strong>&nbsp;&nbsp;</strong><strong>Works and Goods through Shopping</strong></p>
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:10pt;"><strong>(Post Review)</strong></p>
                </td>
            </tr>
            <tr style="height:11.65pt;">
                <td rowspan="2" style="width:38.85pt; border-style:solid; border-width:0.75pt 0.75pt 0.75pt 1pt; padding-right:5.03pt; padding-left:4.9pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Package No.&nbsp;</strong></p>
                </td>
                <td rowspan="2" style="width:88.45pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Name of Contract Package</strong></p>
                </td>
                <td rowspan="2" style="width:52.95pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>&nbsp;</strong><strong>Estimated amount&nbsp;</strong><br><strong>(USD)&nbsp;</strong></p>
                </td>
                <td rowspan="2" style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Date type&nbsp;</strong></p>
                </td>
                <td colspan="4" style="width:315.25pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:1pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:4.9pt; padding-left:5.4pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Milestone Dates&nbsp;</strong><strong><span style="font-size:6pt;"><sup>a</sup></span></strong></p>
                </td>
                <td rowspan="2" style="width:123.85pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:1pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:4.9pt; padding-left:5.4pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Remarks</strong></p>
                </td>
            </tr>
            <tr style="height:7.15pt;">
                <td style="width:95.55pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Request for Quotations advertised</strong></p>
                </td>
                <td style="width:81.3pt; border-style:solid; border-width:0.75pt 1pt 0.75pt 0.75pt; padding-right:4.9pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Evaluation approved by CSC</strong></p>
                </td>
                <td style="width:45.9pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:1pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:4.9pt; padding-left:5.4pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Award of Contract</strong></p>
                </td>
                <td style="width:60.1pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:1pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:4.9pt; padding-left:5.4pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Intended Completion</strong></p>
                </td>
            </tr>
            <tr style="height:7.15pt;">
                <td rowspan="2" style="width:38.85pt; border-style:solid; border-width:0.75pt 0.75pt 1pt 1pt; padding-right:5.03pt; padding-left:4.9pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">&nbsp;</p>
                </td>
                <td rowspan="2" style="width:88.45pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:1pt; padding-right:5.03pt; padding-left:5.4pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;"><strong>&nbsp;</strong></p>
                </td>
                <td rowspan="2" style="width:52.95pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:1pt; padding-right:5.03pt; padding-left:5.4pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Planned</p>
                </td>
                <td style="width:95.55pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:1pt; padding-right:5.03pt; padding-left:5.4pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:81.3pt; border-style:solid; border-width:0.75pt 1pt 1pt 0.75pt; padding-right:4.9pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:45.9pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:1pt; padding-right:5.03pt; padding-left:5.4pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:60.1pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:123.85pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
            <tr style="height:7.15pt;">
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Actual</p>
                </td>
                <td style="width:95.55pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:1pt; padding-right:5.03pt; padding-left:5.4pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:81.3pt; border-style:solid; border-width:0.75pt 1pt 1pt 0.75pt; padding-right:4.9pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:45.9pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:1pt; padding-right:5.03pt; padding-left:5.4pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:60.1pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:123.85pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
            <tr style="height:7.15pt;">
                <td rowspan="2" style="width:38.85pt; border-style:solid; border-width:0.75pt 0.75pt 0.75pt 1pt; padding-right:5.03pt; padding-left:4.9pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">&nbsp;</p>
                </td>
                <td rowspan="2" style="width:88.45pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td rowspan="2" style="width:52.95pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Planned</p>
                </td>
                <td style="width:95.55pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:1pt; padding-right:5.03pt; padding-left:5.4pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:81.3pt; border-style:solid; border-width:0.75pt 1pt 1pt 0.75pt; padding-right:4.9pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:45.9pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:1pt; padding-right:5.03pt; padding-left:5.4pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:60.1pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:123.85pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
            <tr style="height:7.15pt;">
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Actual</p>
                </td>
                <td style="width:95.55pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:81.3pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:60.1pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:123.85pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
        </thead>
    </table>
    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
    <p style="margin-top:0pt; margin-bottom:0pt;">&nbsp;</p>
</div>


        </div>
    </div>
</div>
</body>
</html>