<div class="pcoded-content">
    <div class="pcoded-inner-content">
        <div class="main-body">
            <div class="page-wrapper">
                <div class="page-header">
                    <div class="page-header-title"></div>
                    <div class="page-header-breadcrumb">
                    
                    </div>
                </div>
                <div class="page-body">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="card">
                                
                                <div class="card-block">
                                    <div class="dt-responsive table-responsive">
                                    <h2 style="margin-top:0pt; margin-left:53.5pt; margin-bottom:12pt; text-indent:-18pt; text-align:left; font-size:11pt;">ii)<span style="width:8.22pt; font:7pt 'Times New Roman'; display:inline-block;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><a name="_Toc148522788">Appendix-6: Pipeline Contracts &ndash; To Be Awarded under The Project</a></h2>
    <table cellspacing="0" cellpadding="0" style="width:730.05pt; margin-right:9pt; margin-left:9pt; border-collapse:collapse; float:left;">
        <thead>
            <tr style="height:7.15pt;">
                <td colspan="13" style="width:719.25pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.4pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:11pt;"><strong>Table A6.1: Works, Goods and Non-consulting Services Contracts through Open Competitive Bidding Single Stage-Two Envelope</strong></p>
                </td>
            </tr>
            <tr style="height:7.15pt;">
                <td rowspan="2" style="width:38.85pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;"><strong>Package/ Lot # as in PP</strong></p>
                </td>
                <td rowspan="2" style="width:109.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;"><strong>Name of Contract Package</strong></p>
                </td>
                <td rowspan="2" style="width:38.85pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;"><strong>Est. Amt.</strong></p>
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;"><strong>($ million)</strong></p>
                </td>
                <td rowspan="2" style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;"><strong>Planned/ Approved</strong></p>
                </td>
                <td colspan="8" style="width:364.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;"><strong>Milestone Dates</strong></p>
                </td>
                <td rowspan="2" style="width:67.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;"><strong>Remarks</strong></p>
                </td>
            </tr>
            <tr style="height:7.15pt;">
                <td style="width:24.6pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;"><strong>IFB</strong></p>
                </td>
                <td style="width:38.85pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Technical Bid Opening</strong></p>
                </td>
                <td style="width:24.6pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>TBER to ADB</strong></p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>ADB Approval</strong></p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Financial Bid opening</strong></p>
                </td>
                <td style="width:31.75pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>PBER to ADB</strong></p>
                </td>
                <td style="width:38.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>ADB approval</strong></p>
                </td>
                <td style="width:38.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Contract Award</strong></p>
                </td>
            </tr>
            <tr style="height:7.95pt;">
                <td style="width:38.85pt; border-top-style:solid; border-top-width:0.75pt; border-left-style:solid; border-left-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.4pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;"><strong>&nbsp;</strong></p>
                </td>
                <td style="width:109.65pt; border-top-style:solid; border-top-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.4pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:38.85pt; border-top-style:solid; border-top-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.4pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:45.9pt; border-top-style:solid; border-top-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.4pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:24.6pt; border-top-style:solid; border-top-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.4pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:38.85pt; border-top-style:solid; border-top-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.4pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:24.6pt; border-top-style:solid; border-top-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.4pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:45.9pt; border-top-style:solid; border-top-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.4pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:45.9pt; border-top-style:solid; border-top-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.4pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:31.75pt; border-top-style:solid; border-top-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.4pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:38.8pt; border-top-style:solid; border-top-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.4pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:38.8pt; border-top-style:solid; border-top-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.4pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:67.2pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
        </thead>
        <tbody>
            <tr style="height:19.5pt;">
                <td rowspan="2" style="width:38.85pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">CW-05:</p>
                </td>
                <td rowspan="2" style="width:109.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Procurement, Supply, Installation, commissioning and operations of Solid waste management system MARDAN</p>
                </td>
                <td rowspan="2" style="width:38.85pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">24.87</p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Planned</p>
                </td>
                <td style="width:24.6pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q3-2023</p>
                </td>
                <td style="width:38.85pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q4-2023</p>
                </td>
                <td style="width:24.6pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q4-2023</p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q4-2023</p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q4-2023</p>
                </td>
                <td style="width:31.75pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Q4-2023</p>
                </td>
                <td style="width:38.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q4-2023</p>
                </td>
                <td style="width:38.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q4-2023</p>
                </td>
                <td style="width:67.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
            <tr style="height:7.15pt;">
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Actual</p>
                </td>
                <td style="width:24.6pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:38.85pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:24.6pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:31.75pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:38.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:38.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:67.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
            <tr style="height:34.35pt;">
                <td rowspan="2" style="width:38.85pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">CW-06:</p>
                </td>
                <td rowspan="2" style="width:109.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Construction of Urban / Green Spaces &ndash; Salhad Bagh, ABBOTTABAD</p>
                </td>
                <td rowspan="2" style="width:38.85pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">5.44</p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Planned</p>
                </td>
                <td style="width:24.6pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q3-2026</p>
                </td>
                <td style="width:38.85pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q3-2026</p>
                </td>
                <td style="width:24.6pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q3-2026</p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q3-2026</p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q4-2026</p>
                </td>
                <td style="width:31.75pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Q4-2026</p>
                </td>
                <td style="width:38.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q4-2026</p>
                </td>
                <td style="width:38.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q4-2026</p>
                </td>
                <td rowspan="2" style="width:67.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Once the CW-07 is near to completion, the procurement will start for CW-06</p>
                </td>
            </tr>
            <tr style="height:7.15pt;">
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Actual</p>
                </td>
                <td style="width:24.6pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:38.85pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:24.6pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:31.75pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:38.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:38.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
            <tr style="height:19.05pt;">
                <td rowspan="2" style="width:38.85pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">CW-07: Lot-1</p>
                </td>
                <td rowspan="2" style="width:109.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Procurement, Supply, Installation, commissioning and operations of Solid waste management system PESHAWAR</p>
                </td>
                <td rowspan="2" style="width:38.85pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">77.11</p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Planned</p>
                </td>
                <td style="width:24.6pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q2-2023</p>
                </td>
                <td style="width:38.85pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q3-2023</p>
                </td>
                <td style="width:24.6pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q3-2023</p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q4-2023</p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q4-2023</p>
                </td>
                <td style="width:31.75pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Q4-2023</p>
                </td>
                <td style="width:38.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q4-2023</p>
                </td>
                <td style="width:38.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q4-2023</p>
                </td>
                <td style="width:67.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
            <tr style="height:7.15pt;">
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Actual</p>
                </td>
                <td style="width:24.6pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:38.85pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:24.6pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:31.75pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:38.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:38.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:67.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
            <tr style="height:19.95pt;">
                <td rowspan="2" style="width:38.85pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">CW-07: Lot-2</p>
                </td>
                <td rowspan="2" style="width:109.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Procurement, Supply, Installation, commissioning and operations of Solid waste management system KOHAT</p>
                </td>
                <td rowspan="2" style="width:38.85pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">23.60</p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Planned</p>
                </td>
                <td style="width:24.6pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q2-2023</p>
                </td>
                <td style="width:38.85pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q3-2023</p>
                </td>
                <td style="width:24.6pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q3-2023</p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q4-2023</p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q4-2023</p>
                </td>
                <td style="width:31.75pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Q4-2023</p>
                </td>
                <td style="width:38.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q4-2023</p>
                </td>
                <td style="width:38.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q4-2023</p>
                </td>
                <td style="width:67.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
            <tr style="height:7.15pt;">
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Actual</p>
                </td>
                <td style="width:24.6pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:38.85pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:24.6pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:31.75pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:38.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:38.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:67.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
            <tr style="height:39.75pt;">
                <td rowspan="2" style="width:38.85pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">CW-07: Lot-3</p>
                </td>
                <td rowspan="2" style="width:109.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Procurement, Supply, Installation, commissioning and operations of Solid waste management system MINGORA</p>
                </td>
                <td rowspan="2" style="width:38.85pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">13.45</p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Planned</p>
                </td>
                <td style="width:24.6pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:38.85pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:24.6pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:31.75pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:38.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:38.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td rowspan="2" style="width:67.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">The sub-project will be shifted to some other site as the current site is not feasible &ndash; GoKP to decide.</p>
                </td>
            </tr>
            <tr style="height:7.15pt;">
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Actual</p>
                </td>
                <td style="width:24.6pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:38.85pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:24.6pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:31.75pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:38.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:38.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
            <tr style="height:28.95pt;">
                <td rowspan="2" style="width:38.85pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">CW-07: Lot-4</p>
                </td>
                <td rowspan="2" style="width:109.65pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">CW-07: Procurement, Supply, Installation, commissioning and operations of Solid waste management system ABBOTABAD</p>
                </td>
                <td rowspan="2" style="width:38.85pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">24.04</p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Planned</p>
                </td>
                <td style="width:24.6pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q2-2023</p>
                </td>
                <td style="width:38.85pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q3-2023</p>
                </td>
                <td style="width:24.6pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q3-2023</p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q4-2023</p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q4-2023</p>
                </td>
                <td style="width:31.75pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q4-2023</p>
                </td>
                <td style="width:38.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q4-2023</p>
                </td>
                <td style="width:38.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Q4-2023</p>
                </td>
                <td style="width:67.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
            <tr style="height:7.15pt;">
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">Actual</p>
                </td>
                <td style="width:24.6pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:38.85pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:24.6pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:31.75pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:38.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:38.8pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:67.2pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
        </tbody>
    </table>
    
    <table cellspacing="0" cellpadding="0" style="width:954pt; margin-right:9pt; margin-left:9pt; border-collapse:collapse; float:left;">
        <thead>
            <tr style="height:50.9pt;">
                <td colspan="10" style="border-bottom-style:solid; border-bottom-width:0.75pt;">
                    <p style="margin:0pt 29.45pt 0pt 29.5pt; text-align:center; widows:0; orphans:0; font-size:11pt;"><strong>Procurement Contracts Monitoring Sheet</strong></p>
                    <p style="margin:0pt 29.45pt 0pt 29.5pt; text-align:center; widows:0; orphans:0; font-size:11pt;"><strong>Table A6.2: Works and Goods through Shopping</strong></p>
                    <p style="margin:0pt 29.45pt 0pt 29.5pt; text-align:center; widows:0; orphans:0; font-size:11pt;"><strong>(Prior Review)</strong></p>
                </td>
            </tr>
            <tr style="height:14.75pt;">
                <td rowspan="2" style="border-style:solid; border-width:0.75pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Package No.</strong></p>
                </td>
                <td rowspan="2" style="border-style:solid; border-width:0.75pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Name of Contract Package</strong></p>
                </td>
                <td rowspan="2" style="border-style:solid; border-width:0.75pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Estimated amount (PKR)</strong></p>
                </td>
                <td rowspan="2" style="border-style:solid; border-width:0.75pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Date type</strong></p>
                </td>
                <td colspan="5" style="border-style:solid; border-width:0.75pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Milestone Dates a</strong></p>
                </td>
                <td rowspan="2" style="border-style:solid; border-width:0.75pt; background-color:#f2f2f2;">
                    <p style="margin:0.35pt 3.75pt 0pt 4.1pt; text-align:center; line-height:114%; widows:0; orphans:0; font-size:9pt;"><strong>Remarks</strong></p>
                </td>
            </tr>
            <tr style="height:48.1pt;">
                <td style="border-style:solid; border-width:0.75pt; background-color:#f2f2f2;">
                    <p style="margin:0.35pt 4.75pt 0pt 5.85pt; text-indent:-0.85pt; text-align:center; line-height:114%; widows:0; orphans:0; font-size:9pt;"><strong>RFQs advertised</strong></p>
                </td>
                <td style="border-style:solid; border-width:0.75pt; background-color:#f2f2f2;">
                    <p style="margin:0.35pt 3.75pt 0pt 4.1pt; text-align:center; line-height:114%; widows:0; orphans:0; font-size:9pt;"><strong>Evaluation Report to ADB.</strong></p>
                </td>
                <td style="border-style:solid; border-width:0.75pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-right:1.7pt; margin-bottom:0pt; text-align:center; widows:0; orphans:0; font-size:9pt;"><strong>ADB approval</strong></p>
                </td>
                <td style="border-style:solid; border-width:0.75pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-right:0.95pt; margin-bottom:0pt; text-align:center; widows:0; orphans:0; font-size:9pt;"><strong>Contract Award</strong></p>
                </td>
                <td style="border-style:solid; border-width:0.75pt; background-color:#f2f2f2;">
                    <p style="margin:3.95pt 1.9pt 0pt 3.1pt; text-indent:3.6pt; text-align:center; line-height:114%; widows:0; orphans:0; font-size:9pt;"><strong>Intended Completion</strong></p>
                </td>
            </tr>
            <tr style="height:7.75pt;">
                <td style="border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-left-style:solid; border-left-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-left-style:solid; border-left-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-left-style:solid; border-left-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-left-style:solid; border-left-width:0.75pt;">
                    <p style="margin-top:0.4pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-left-style:solid; border-left-width:0.75pt;">
                    <p style="margin-top:0.4pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-left-style:solid; border-left-width:0.75pt;">
                    <p style="margin-top:0.4pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-left-style:solid; border-left-width:0.75pt;">
                    <p style="margin-top:0.4pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-left-style:solid; border-left-width:0.75pt;">
                    <p style="margin-top:0.4pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-left-style:solid; border-left-width:0.75pt;">
                    <p style="margin-top:0.4pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-left-style:solid; border-left-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
        </thead>
        <tbody>
            <tr style="height:23.15pt;">
                <td rowspan="2" style="border-right-style:solid; border-right-width:0.75pt; border-left-style:solid; border-left-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt;">
                    <p style="margin-top:5.15pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">03A / 01</p>
                </td>
                <td rowspan="2" style="border-right-style:solid; border-right-width:0.75pt; border-left-style:solid; border-left-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; line-height:108%; widows:0; orphans:0; font-size:9pt;">KPCIP - Shopping - Goods: General Office Equipment</p>
                </td>
                <td rowspan="2" style="border-right-style:solid; border-right-width:0.75pt; border-left-style:solid; border-left-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt;">
                    <p style="margin-top:5.15pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">7,605,200</p>
                </td>
                <td style="border-right-style:solid; border-right-width:0.75pt; border-left-style:solid; border-left-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.5pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Planned</p>
                </td>
                <td style="border-right-style:solid; border-right-width:0.75pt; border-left-style:solid; border-left-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:6.2pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Jul-22</p>
                </td>
                <td style="border-right-style:solid; border-right-width:0.75pt; border-left-style:solid; border-left-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">-</p>
                </td>
                <td style="border-right-style:solid; border-right-width:0.75pt; border-left-style:solid; border-left-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:1.7pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Sep-22</p>
                </td>
                <td style="border-right-style:solid; border-right-width:0.75pt; border-left-style:solid; border-left-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">-</p>
                </td>
                <td style="border-right-style:solid; border-right-width:0.75pt; border-left-style:solid; border-left-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">-</p>
                </td>
                <td style="border-right-style:solid; border-right-width:0.75pt; border-left-style:solid; border-left-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
            <tr style="height:33.7pt;">
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.45pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Actual</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:6.3pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">24-Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.85pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">26-Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:1.7pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">27-Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:0.95pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">28-Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.85pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">6-Oct-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
            <tr style="height:23.15pt;">
                <td rowspan="2" style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:5.15pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">03A / 02</p>
                </td>
                <td rowspan="2" style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-left:0.7pt; margin-bottom:0pt; line-height:108%; widows:0; orphans:0; font-size:9pt;">KPCIP - Shopping - Goods: Procurement of General Office Equipment</p>
                </td>
                <td rowspan="2" style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:5.15pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">1,697,850</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.5pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Planned</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:6.2pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Jul-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:1.7pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
            <tr style="height:23.15pt;">
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.45pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Actual</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:6.3pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">27-Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.85pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">28-Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:1.7pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">29-Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:0.95pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">4-Oct-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.85pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">10-Oct-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
            <tr style="height:23.15pt;">
                <td rowspan="2" style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:5.15pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">03B / 01</p>
                </td>
                <td rowspan="2" style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-left:0.7pt; margin-bottom:0pt; line-height:108%; widows:0; orphans:0; font-size:9pt;">KPCIP - Shopping - Goods: Procurement of IT Equipments (PMU)</p>
                </td>
                <td rowspan="2" style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:5.15pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">13,240,000</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.5pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Planned</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:6.2pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Jul-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:1.7pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
            <tr style="height:23.15pt;">
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.45pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Actual</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:6.2pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">4-Nov-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.85pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">6-Nov-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:1.7pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">7-Nov-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:0.95pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">16-Oct-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.85pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">24-Nov-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
            <tr style="height:23.15pt;">
                <td rowspan="2" style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:5.15pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">03B / 02</p>
                </td>
                <td rowspan="2" style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-left:0.7pt; margin-bottom:0pt; line-height:108%; widows:0; orphans:0; font-size:9pt;">KPCIP - Shopping - Goods: Procurement of IT Equipments (CIUS)</p>
                </td>
                <td rowspan="2" style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:5.15pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">15,600,000</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.5pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Planned</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:6.2pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Jul-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:1.7pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
            <tr style="height:23.15pt;">
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.45pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Actual</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:6.2pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">4-Nov-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.85pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">6-Nov-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:1.7pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">7-Nov-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:0.95pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">16-Oct-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.85pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">24-Nov-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
            <tr style="height:23.15pt;">
                <td rowspan="2" style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:5.15pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">03C / 01</p>
                </td>
                <td rowspan="2" style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-left:0.7pt; margin-bottom:0pt; line-height:108%; widows:0; orphans:0; font-size:9pt;">KPCIP - Shopping - Goods: Procurement of Office Furniture</p>
                </td>
                <td rowspan="2" style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:5.15pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">13,540,000</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.5pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Planned</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:6.2pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Jul-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:1.7pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
            <tr style="height:23.15pt;">
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.45pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Actual</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:6.2pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">18-Oct-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.85pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">20-Oct-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:1.7pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">24-Oct-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:0.95pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">31-Oct-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.85pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">4-Nov-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
            <tr style="height:23.15pt;">
                <td rowspan="2" style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:5.15pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">03D / 01</p>
                </td>
                <td rowspan="2" style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-left:0.7pt; margin-bottom:0pt; line-height:108%; widows:0; orphans:0; font-size:9pt;">KPCIP - Shopping - Goods: Procurement &amp; Supply of Vehicles (Mid-Sized Sedan Car with 1.5/1.6 L Engine &amp; Auto Transmission (08 Nos.) for PMU</p>
                </td>
                <td rowspan="2" style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:5.15pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">39,792,000</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.5pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Planned</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:6.2pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Jul-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:1.7pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
            <tr style="height:35.95pt;">
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.45pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Actual</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:6.3pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">27-Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.85pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">28-Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:1.7pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">29-Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:0.95pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">3-Oct-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.85pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">10-Oct-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
            <tr style="height:23.15pt;">
                <td rowspan="2" style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:5.15pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">03D / 02</p>
                </td>
                <td rowspan="2" style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-left:0.7pt; margin-bottom:0pt; line-height:108%; widows:0; orphans:0; font-size:9pt;">KPCIP - Shopping - Goods: Procurement of Motor Bikes</p>
                </td>
                <td rowspan="2" style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:5.15pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">4,491,375</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.5pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Planned</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:6.2pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Jul-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-left:0.2pt; margin-bottom:0pt; text-align:center; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:1.7pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-left:0.3pt; margin-bottom:0pt; text-align:center; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-left:0.25pt; margin-bottom:0pt; text-align:center; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
            <tr style="height:27pt;">
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.45pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Actual</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:6.3pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">27-Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.85pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">28-Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:1.7pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">29-Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:0.95pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">4-Oct-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.85pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">10-Oct-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
            <tr style="height:36.25pt;">
                <td rowspan="2" style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:5.15pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">03D / 03</p>
                </td>
                <td rowspan="2" style="border-style:solid; border-width:0.75pt;">
                    <p style="margin:0pt 0.25pt 0pt 0.7pt; line-height:4.9pt; widows:0; orphans:0;"><span style="font-size:9pt;">KPCIP - Shopping - Goods: Procurement &amp;</span></p>
                    <p style="margin:0.5pt 0.25pt 0pt 0.7pt; line-height:108%; widows:0; orphans:0; font-size:9pt;">Supply of: (I) Vehicle [07 Seater, 05 Door Vehicle &apos;JEEP&apos; (4X4) (2700 to 2800 CC) -</p>
                    <p style="margin:0pt 0.25pt 0pt 0.7pt; line-height:108%; widows:0; orphans:0; font-size:9pt;">Fortuner Legender (01 No.)] AND (II) Mid - Sized Sedan Car with 1.3/1.5 L Engine &amp; Auto Transmission Toyota YARIS ATIV CVT (07 Nos.) for PMU</p>
                </td>
                <td rowspan="2" style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:5.15pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">46,839,000</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.5pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Planned</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:6.2pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Jul-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:1.7pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
            <tr style="height:37.6pt;">
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.45pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Actual</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:6.3pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">27-Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.85pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">28-Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:1.7pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">29-Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:0.95pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">3-Oct-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.85pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">10-Oct-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
            <tr style="height:23.15pt;">
                <td rowspan="2" style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:5.15pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">03D / 04</p>
                </td>
                <td rowspan="2" style="border-style:solid; border-width:0.75pt;">
                    <p style="margin:0pt 0.85pt 0pt 0.7pt; line-height:108%; widows:0; orphans:0; font-size:9pt;">KPCIP - Shopping - Goods: Procurement of Mid - Sized Sedan Car with 1.3/1.5 L Engine &amp; Auto Transmission (10 Nos.) for CIU&apos;s</p>
                </td>
                <td rowspan="2" style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:5.15pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">41,070,000</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.5pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Planned</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:6.2pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Jul-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:1.7pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
            <tr style="height:23.15pt;">
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.45pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Actual</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:6.3pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">27-Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.85pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">28-Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:1.7pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">29-Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:0.95pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">5-Oct-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.85pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">10-Oct-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
            <tr style="height:23.15pt;">
                <td rowspan="2" style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:5.15pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">03D / 05</p>
                </td>
                <td rowspan="2" style="border-style:solid; border-width:0.75pt;">
                    <p style="margin:0pt 0.85pt 0pt 0.7pt; line-height:108%; widows:0; orphans:0; font-size:9pt;">KPCIP - Shopping - Goods: Procurement of Mid - Sized Sedan Car with 1.3/1.5 L Engine &amp; Auto Transmission (08 Nos.) for PMCSC</p>
                </td>
                <td rowspan="2" style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:5.15pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">32,856,000</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.5pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Planned</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:6.2pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Jul-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:1.7pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
            <tr style="height:36.7pt;">
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.45pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Actual</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:6.3pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">27-Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.85pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">28-Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:1.7pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">29-Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:0.95pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">5-Oct-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.85pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">10-Oct-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
            <tr style="height:23.15pt;">
                <td rowspan="2" style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:5.15pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">03D / 06</p>
                </td>
                <td rowspan="2" style="border-style:solid; border-width:0.75pt;">
                    <p style="margin:0pt 0.85pt 0pt 0.7pt; line-height:108%; widows:0; orphans:0; font-size:9pt;">KPCIP - Shopping - Goods: Procurement of Mid - Sized Sedan Car with 1.3/1.5 L Engine &amp; Auto Transmission (09 Nos.) for PMCSC</p>
                </td>
                <td rowspan="2" style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:5.15pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">36,963,000</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.5pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Planned</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:6.2pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Jul-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:1.7pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
            <tr style="height:23.15pt;">
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.45pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">Actual</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:6.3pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">27-Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.85pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">28-Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:1.7pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">29-Sep-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:0.95pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">5-Oct-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-right:3.85pt; margin-bottom:0pt; widows:0; orphans:0; font-size:9pt;">10-Oct-22</p>
                </td>
                <td style="border-style:solid; border-width:0.75pt;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
        </tbody>
    </table>
   
    <table cellspacing="0" cellpadding="0" style="width:954pt; margin-right:9pt; margin-left:9pt; border-collapse:collapse; float:left;">
        <thead>
            <tr style="height:11.65pt;">
                <td colspan="9" style="width:719.25pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.4pt; padding-left:5.4pt; vertical-align:bottom;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:10pt;"><strong>Table A6.3:</strong><strong>&nbsp;&nbsp;</strong><strong>Works and Goods through Shopping</strong></p>
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:10pt;"><strong>(Post Review)</strong></p>
                </td>
            </tr>
            <tr style="height:11.65pt;">
                <td rowspan="2" style="width:38.85pt; border-style:solid; border-width:0.75pt 0.75pt 0.75pt 1pt; padding-right:5.03pt; padding-left:4.9pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Package No.&nbsp;</strong></p>
                </td>
                <td rowspan="2" style="width:88.45pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Name of Contract Package</strong></p>
                </td>
                <td rowspan="2" style="width:52.95pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>&nbsp;</strong><strong>Estimated amount&nbsp;</strong><br><strong>(USD)&nbsp;</strong></p>
                </td>
                <td rowspan="2" style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Date type&nbsp;</strong></p>
                </td>
                <td colspan="4" style="width:315.25pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:1pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:4.9pt; padding-left:5.4pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Milestone Dates&nbsp;</strong><strong><span style="font-size:6pt;"><sup>a</sup></span></strong></p>
                </td>
                <td rowspan="2" style="width:123.85pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:1pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:4.9pt; padding-left:5.4pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Remarks</strong></p>
                </td>
            </tr>
            <tr style="height:7.15pt;">
                <td style="width:95.55pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Request for Quotations advertised</strong></p>
                </td>
                <td style="width:81.3pt; border-style:solid; border-width:0.75pt 1pt 0.75pt 0.75pt; padding-right:4.9pt; padding-left:5.03pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Evaluation approved by CSC</strong></p>
                </td>
                <td style="width:45.9pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:1pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:4.9pt; padding-left:5.4pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Award of Contract</strong></p>
                </td>
                <td style="width:60.1pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:1pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:4.9pt; padding-left:5.4pt; background-color:#f2f2f2;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;"><strong>Intended Completion</strong></p>
                </td>
            </tr>
            <tr style="height:7.15pt;">
                <td rowspan="2" style="width:38.85pt; border-style:solid; border-width:0.75pt 0.75pt 1pt 1pt; padding-right:5.03pt; padding-left:4.9pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">&nbsp;</p>
                </td>
                <td rowspan="2" style="width:88.45pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:1pt; padding-right:5.03pt; padding-left:5.4pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;"><strong>&nbsp;</strong></p>
                </td>
                <td rowspan="2" style="width:52.95pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:1pt; padding-right:5.03pt; padding-left:5.4pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Planned</p>
                </td>
                <td style="width:95.55pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:1pt; padding-right:5.03pt; padding-left:5.4pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:81.3pt; border-style:solid; border-width:0.75pt 1pt 1pt 0.75pt; padding-right:4.9pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:45.9pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:1pt; padding-right:5.03pt; padding-left:5.4pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:60.1pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:123.85pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
            <tr style="height:7.15pt;">
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Actual</p>
                </td>
                <td style="width:95.55pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:1pt; padding-right:5.03pt; padding-left:5.4pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:81.3pt; border-style:solid; border-width:0.75pt 1pt 1pt 0.75pt; padding-right:4.9pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:45.9pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:1pt; padding-right:5.03pt; padding-left:5.4pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:60.1pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:123.85pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
            <tr style="height:7.15pt;">
                <td rowspan="2" style="width:38.85pt; border-style:solid; border-width:0.75pt 0.75pt 0.75pt 1pt; padding-right:5.03pt; padding-left:4.9pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">&nbsp;</p>
                </td>
                <td rowspan="2" style="width:88.45pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td rowspan="2" style="width:52.95pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Planned</p>
                </td>
                <td style="width:95.55pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:1pt; padding-right:5.03pt; padding-left:5.4pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:81.3pt; border-style:solid; border-width:0.75pt 1pt 1pt 0.75pt; padding-right:4.9pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:45.9pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:1pt; padding-right:5.03pt; padding-left:5.4pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:60.1pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:123.85pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:justify; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
            <tr style="height:7.15pt;">
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">Actual</p>
                </td>
                <td style="width:95.55pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.4pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:81.3pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:45.9pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:60.1pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
                <td style="width:123.85pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top;">
                    <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:9pt;">&nbsp;</p>
                </td>
            </tr>
        </thead>
    </table>